import React from 'react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

// Helper to render character grid boxes with exact sizing & crisp text
const renderLetterBoxes = (str = '', length = 25, boxWidth = '15.5px', boxHeight = '19.5px', fontSize = '12px') => {
  const chars = (str || '').toUpperCase().padEnd(length, ' ').slice(0, length).split('');
  return (
    <div style={{ display: 'flex', flexWrap: 'nowrap', gap: '0px' }}>
      {chars.map((ch, i) => (
        <div
          key={i}
          style={{
            width: boxWidth,
            height: boxHeight,
            border: '1.2px solid #000',
            borderLeft: i > 0 ? 'none' : '1.2px solid #000',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: fontSize,
            fontWeight: 'bold',
            fontFamily: 'monospace',
            background: '#fff',
            color: '#000',
            boxSizing: 'border-box'
          }}
        >
          {ch !== ' ' ? ch : ''}
        </div>
      ))}
    </div>
  );
};

// Helper for Checkboxes with tick mark and readable font size
const BoxCheck = ({ checked, label }) => (
  <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', fontSize: '10.5px' }}>
    <span
      style={{
        width: '13px',
        height: '13px',
        border: '1.2px solid #000',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: '11px',
        fontWeight: 'bold',
        background: '#fff',
        lineHeight: 1,
        boxSizing: 'border-box'
      }}
    >
      {checked ? '✓' : ''}
    </span>
    {label && <span style={{ fontWeight: checked ? 'bold' : 'normal', color: '#000' }}>{label}</span>}
  </span>
);

export const generateForm49APdf = async (data = {}, elementId = 'pancr-pdf-container') => {
  const element = document.getElementById(elementId);
  if (!element) {
    console.error('PAN CR container element not found');
    return false;
  }

  // Pre-open window synchronously to avoid browser pop-up blocking
  const newWin = window.open('', '_blank');
  if (newWin) {
    newWin.document.write('<html><head><title>Generating PAN CR PDF...</title></head><body style="font-family:sans-serif;display:flex;justify-content:center;align-items:center;height:100vh;background:#0f172a;color:#fff;"><h2>Generating your PAN CR PDF... Please wait.</h2></body></html>');
  }

  // Make container temporarily visible for capturing
  const originalDisplay = element.style.display;
  element.style.display = 'block';

  try {
    const page1 = document.getElementById(`${elementId}-page1`);
    const page2 = document.getElementById(`${elementId}-page2`);

    const pdf = new jsPDF('p', 'mm', 'a4');
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = pdf.internal.pageSize.getHeight();

    // Render Page 1
    if (page1) {
      const canvas1 = await html2canvas(page1, { scale: 2, useCORS: true, logging: false });
      const imgData1 = canvas1.toDataURL('image/jpeg', 0.98);
      pdf.addImage(imgData1, 'JPEG', 0, 0, pdfWidth, pdfHeight);
    }

    // Render Page 2
    if (page2) {
      pdf.addPage();
      const canvas2 = await html2canvas(page2, { scale: 2, useCORS: true, logging: false });
      const imgData2 = canvas2.toDataURL('image/jpeg', 0.98);
      pdf.addImage(imgData2, 'JPEG', 0, 0, pdfWidth, pdfHeight);
    }

    const fileName = `PAN_CR_01_${(data.lastName || data.nameAsPerAadhaar || 'Application').replace(/\s+/g, '_')}.pdf`;
    const pdfBlob = pdf.output('blob');
    const blobUrl = URL.createObjectURL(pdfBlob);

    // Save / Download locally
    pdf.save(fileName);

    // Open blob PDF in pre-opened tab
    if (newWin) {
      newWin.location.href = blobUrl;
    }
    return true;
  } catch (err) {
    console.error('Error generating PDF:', err);
    if (newWin) newWin.close();
    return false;
  } finally {
    element.style.display = originalDisplay;
  }
};


const Form49APdfTemplate = ({ data = {} }) => {
  const today = new Date();
  const dayStr = String(today.getDate()).padStart(2, '0');
  const monthStr = String(today.getMonth() + 1).padStart(2, '0');
  const yearStr = String(today.getFullYear());

  // Format DOB string into DD MM YYYY.
  let dobDay = '', dobMonth = '', dobYear = '';
  if (data.dob) {
    const parts = String(data.dob).split('-');
    if (parts.length === 3) {
      dobYear = parts[0];
      dobMonth = parts[1];
      dobDay = parts[2];
    }
  }

  const fullNameStr = `${data.firstName || ''} ${data.middleName || ''} ${data.lastName || ''}`
    .replace(/\s+/g, ' ')
    .trim();

  const aadhaarName = (data.nameAsPerAadhaar || fullNameStr).toUpperCase();

  const address = data.address || data.residenceAddress || {};

  const field = (primary, fallback = '') => data[primary] ?? fallback;

  const text = {
    pan: field('panNumber', field('pan')),
    aadhaar: field('aadhaarNumber', field('aadhaar')),
    firstName: field('firstName'),
    middleName: field('middleName'),
    lastName: field('lastName'),
    aadhaarName,
    fatherFirstName: field('fatherFirstName'),
    fatherMiddleName: field('fatherMiddleName'),
    fatherLastName: field('fatherLastName'),
    motherFirstName: field('motherFirstName'),
    motherMiddleName: field('motherMiddleName'),
    motherLastName: field('motherLastName'),
    passport: field('passportNumber'),
    tin: field('tin'),
    mobile: field('mobileNumber', field('mobile')),
    countryCode: field('countryCode', '91'),
    email: field('email'),
    isdCode: field('isdCode', field('countryCode', '91')),
    stdCode: field('stdCode'),
    landline: field('landlineNumber'),
    flat: field('flatDoorBuilding', address.flatDoorBuilding || address.flatNo),
    road: field('roadStreetBlock', address.roadStreetBlock || address.roadStreet),
    postOffice: field('postOffice', address.postOffice),
    area: field('areaLocality', address.areaLocality || address.areaTaluka),
    district: field('district', address.district),
    state: field('state', address.state),
    country: field('country', address.country || 'INDIA'),
    pincode: field('pincode', address.pincode),
  };

  const selected = {
    name: Boolean(data.nameCorrection ?? data.nameChanged ?? data.changeName),
    gender: Boolean(data.genderCorrection ?? data.changeGender),
    dob: Boolean(data.dobCorrection ?? data.changeDob),
    address: Boolean(data.addressCorrection ?? data.changeAddress),
    passport: Boolean(data.passportCorrection ?? data.changePassport),
    tin: Boolean(data.tinCorrection ?? data.changeTin),
    contact: Boolean(data.contactCorrection ?? data.changeContact),
    father: Boolean(data.fatherCorrection ?? data.changeFatherName),
    mother: Boolean(data.motherCorrection ?? data.changeMotherName),
    parentPrint: Boolean(data.parentNameCorrection ?? data.changeParentName),
    proofChange: Boolean(data.proofOfChange ?? data.documentaryProof),
    copyPan: Boolean(data.copyOfPan ?? data.panCopy),
  };


  // The correction form uses a narrow left S.No. column, a Tick Box column,
  // and a wide content column. These dimensions are kept in CSS pixels to
  // preserve the original html2canvas/jsPDF workflow.
  const RowNumber = ({ children }) => (
    <div style={{
      width: '43px',
      flex: '0 0 43px',
      minHeight: '20px',
      background: '#e9e9e9',
      borderRight: '1px solid #aaa',
      display: 'flex',
      alignItems: 'center',
      paddingLeft: '6px',
      boxSizing: 'border-box',
      fontWeight: 'bold',
      fontSize: '9px'
    }}>
      {children}
    </div>
  );

  const TickColumn = ({ checked }) => (
    <div style={{
      width: '43px',
      flex: '0 0 43px',
      minHeight: '20px',
      background: '#e9e9e9',
      borderRight: '1px solid #aaa',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxSizing: 'border-box'
    }}>
      <BoxCheck checked={checked} />
    </div>
  );

  const NameLine = ({ label, value }) => (
    <div style={{
      display: 'grid',
      gridTemplateColumns: '100px 1fr',
      alignItems: 'center',
      height: '20px',
      marginBottom: '2px'
    }}>
      <span style={{ fontSize: '9px' }}>{label}</span>
      {renderLetterBoxes(value, 25, '20px', '19px', '11px')}
    </div>
  );

  const AddressLine = ({ label, value }) => (
    <div style={{
      display: 'grid',
      gridTemplateColumns: '130px 1fr',
      alignItems: 'center',
      height: '20px',
      marginBottom: '2px'
    }}>
      <span style={{ fontSize: '9px' }}>{label}</span>
      {renderLetterBoxes(value, 25, '20px', '19px', '11px')}
    </div>
  );

  const SmallBoxes = ({ value = '', length = 2, width = '18px' }) =>
    renderLetterBoxes(value, length, width, '18px', '10px');

  const HeaderNumberBoxes = ({ value = '', length = 10 }) =>
    renderLetterBoxes(value, length, '19px', '19px', '11px');

  return (
    <div
      id="pancr-pdf-container"
      style={{
        display: 'none',
        position: 'absolute',
        left: '-9999px',
        top: '-9999px'
      }}
    >

      {/* =====================================================================
          PAGE 1 - PAN CR-01 / REQUEST FOR CHANGES OR CORRECTION IN PAN DATA
          ===================================================================== */}
      <div
        id="pancr-pdf-container-page1"
        style={{
          width: '794px',
          height: '1123px',
          padding: '14px 15px',
          background: '#fff',
          color: '#000',
          fontFamily: 'Arial, sans-serif',
          fontSize: '9px',
          boxSizing: 'border-box',
          lineHeight: '1.15',
          overflow: 'hidden'
        }}
      >
        <div style={{
          border: '2px solid #666',
          height: '1095px',
          padding: '7px',
          boxSizing: 'border-box',
          overflow: 'hidden'
        }}>

          {/* ------------------------------ HEADER -------------------------- */}
          <div style={{
            height: '164px',
            display: 'grid',
            gridTemplateColumns: '132px 1fr 132px',
            columnGap: '10px',
            alignItems: 'start',
            boxSizing: 'border-box'
          }}>

            {/* Left 4.5cm x 3.5cm photograph */}
            <div style={{
              width: '132px',
              height: '170px',
              border: '1.2px solid #555',
              boxSizing: 'border-box',
              position: 'relative',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              textAlign: 'center',
              overflow: 'visible'
            }}>
              {data.photoUrl ? (
                <img
                  src={data.photoUrl}
                  alt="Applicant"
                  style={{
                    width: '100%',
                    height: '100%',
                    objectFit: 'cover',
                    display: 'block'
                  }}
                />
              ) : (
                <div style={{
                  width: '105px',
                  fontSize: '8px',
                  lineHeight: '1.5',
                  color: '#222'
                }}>
                  Recent colour<br/>
                  photograph of the applicant<br/>
                  (4.5 cm x 3.5 cm)<br/><br/>
                  with Sign/Left thumb<br/>
                  impression across the photo of<br/>
                  the applicant
                </div>
              )}

              {data.signatureUrl && (
                <img
                  src={data.signatureUrl}
                  alt="Signature"
                  style={{
                    position: 'absolute',
                    zIndex: 5,
                    width: '112px',
                    height: '38px',
                    objectFit: 'contain',
                    left: '8px',
                    bottom: '18px',
                    transform: 'rotate(-5deg)'
                  }}
                />
              )}
            </div>

            {/* Centre heading, PAN and Aadhaar */}
            <div style={{
              height: '160px',
              textAlign: 'center',
              paddingTop: '0px',
              boxSizing: 'border-box'
            }}>
              <div style={{
                fontSize: '13px',
                fontWeight: 'bold',
                marginTop: '4px',
                marginBottom: '2px'
              }}>
                Request For Changes Or Correction in PAN Data
              </div>

              <div style={{
                fontSize: '11px',
                fontWeight: 'bold',
                marginBottom: '15px'
              }}>
                [For an Individual]
              </div>

              <div style={{
                fontSize: '9px',
                fontWeight: 'bold',
                marginBottom: '3px'
              }}>
                Permanent Account Number (PAN)
              </div>

              <div style={{
                display: 'flex',
                justifyContent: 'center',
                marginBottom: '14px'
              }}>
                {HeaderNumberBoxes({ value: text.pan, length: 10 })}
              </div>

              <div style={{
                display: 'inline-block',
                minWidth: '194px',
                background: '#e5e5e5',
                fontSize: '9px',
                fontWeight: 'bold',
                padding: '3px 8px',
                boxSizing: 'border-box',
                marginBottom: '2px'
              }}>
                Aadhaar Number
              </div>

              <div style={{
                display: 'flex',
                justifyContent: 'center'
              }}>
                {HeaderNumberBoxes({ value: text.aadhaar, length: 12 })}
              </div>
            </div>

            {/* Right photograph - must remain clean */}
            <div style={{
              width: '132px',
              height: '170px',
              border: '1.2px solid #555',
              boxSizing: 'border-box',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              textAlign: 'center'
            }}>
              {data.photoUrl ? (
                <img
                  src={data.photoUrl}
                  alt="Applicant"
                  style={{
                    width: '100%',
                    height: '100%',
                    objectFit: 'cover',
                    display: 'block'
                  }}
                />
              ) : (
                <div style={{
                  width: '105px',
                  fontSize: '8px',
                  lineHeight: '1.5',
                  color: '#222'
                }}>
                  Recent colour<br/>
                  photograph of the applicant<br/>
                  (4.5 cm x 3.5 cm)
                </div>
              )}
            </div>
          </div>

          {/* ---------------------- PART A TABLE HEADER -------------------- */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '43px 43px 1fr',
            height: '27px',
            border: '1.2px solid #666',
            boxSizing: 'border-box',
            marginTop: '2px',
            fontWeight: 'bold',
            fontSize: '9px'
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              borderRight: '1px solid #777'
            }}>
              Sr. No.
            </div>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              borderRight: '1px solid #777',
              textAlign: 'center'
            }}>
              Tick<br/>Box
            </div>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              PART A - Personal Information
            </div>
          </div>

          {/* ------------------------------ 1A NAME ------------------------ */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '43px 43px 1fr',
            borderLeft: '1.2px solid #666',
            borderRight: '1.2px solid #666',
            borderBottom: '1px solid #aaa',
            minHeight: '99px',
            boxSizing: 'border-box'
          }}>
            <RowNumber>1.</RowNumber>
            <TickColumn checked={selected.name} />

            <div style={{ padding: '4px 5px 3px', boxSizing: 'border-box' }}>
              <div style={{
                background: '#e6e6e6',
                height: '19px',
                display: 'flex',
                alignItems: 'center',
                padding: '0 5px',
                fontWeight: 'bold',
                fontSize: '9px',
                marginBottom: '4px'
              }}>
                A. Name
              </div>

              <NameLine label="First Name" value={text.firstName} />
              <NameLine label="Middle Name" value={text.middleName} />
              <NameLine label="Last Name" value={text.lastName} />
            </div>
          </div>

          {/* ------------------------------ 1B AADHAAR NAME ----------------- */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '43px 43px 1fr',
            borderLeft: '1.2px solid #666',
            borderRight: '1.2px solid #666',
            borderBottom: '1px solid #aaa',
            height: '67px',
            boxSizing: 'border-box'
          }}>
            <div style={{ background: '#e9e9e9' }} />
            <TickColumn checked={selected.name} />
            <div style={{ padding: '3px 5px' }}>
              <div style={{
                background: '#e6e6e6',
                height: '19px',
                display: 'flex',
                alignItems: 'center',
                padding: '0 5px',
                fontWeight: 'bold',
                fontSize: '9px',
                marginBottom: '4px'
              }}>
                B. Name (as per Aadhaar)
              </div>

              {renderLetterBoxes(aadhaarName.replace(/\s/g, ''), 35, '15px', '18px', '10px')}
            </div>
          </div>

          {/* ------------------------------ 2 GENDER ----------------------- */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '43px 43px 1fr',
            minHeight: '27px',
            borderLeft: '1.2px solid #666',
            borderRight: '1.2px solid #666',
            borderBottom: '1px solid #aaa',
            boxSizing: 'border-box'
          }}>
            <RowNumber>2.</RowNumber>
            <TickColumn checked={selected.gender} />
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '13px',
              padding: '0 7px'
            }}>
              <strong>Gender <i>(select one)</i></strong>
              <BoxCheck checked={data.gender === 'MALE'} label="Male" />
              <BoxCheck checked={data.gender === 'FEMALE'} label="Female" />
              <BoxCheck checked={data.gender === 'TRANSGENDER'} label="Transgender" />
            </div>
          </div>

          {/* ------------------------------ 3 DOB -------------------------- */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '43px 43px 1fr',
            minHeight: '27px',
            borderLeft: '1.2px solid #666',
            borderRight: '1.2px solid #666',
            borderBottom: '1px solid #aaa',
            boxSizing: 'border-box'
          }}>
            <RowNumber>3.</RowNumber>
            <TickColumn checked={selected.dob} />
            <div style={{
              display: 'flex',
              alignItems: 'center',
              padding: '0 7px',
              gap: '5px'
            }}>
              <strong style={{ width: '92px' }}>Date of Birth</strong>
              <span>DD</span>
              {SmallBoxes({ value: dobDay, length: 2 })}
              <span style={{ marginLeft: '5px' }}>MM</span>
              {SmallBoxes({ value: dobMonth, length: 2 })}
              <span style={{ marginLeft: '5px' }}>YYYY</span>
              {SmallBoxes({ value: dobYear, length: 4 })}
            </div>
          </div>

          {/* ------------------------------ 4 ADDRESS ---------------------- */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '43px 43px 1fr',
            borderLeft: '1.2px solid #666',
            borderRight: '1.2px solid #666',
            borderBottom: '1px solid #aaa',
            minHeight: '166px',
            boxSizing: 'border-box'
          }}>
            <RowNumber>4.</RowNumber>
            <TickColumn checked={selected.address} />
            <div style={{ padding: '3px 5px', boxSizing: 'border-box' }}>
              <div style={{
                background: '#e6e6e6',
                height: '19px',
                display: 'flex',
                alignItems: 'center',
                padding: '0 5px',
                fontWeight: 'bold',
                fontSize: '9px',
                marginBottom: '4px'
              }}>
                Address
              </div>

              <div style={{
                height: '22px',
                display: 'flex',
                alignItems: 'center',
                paddingLeft: '4px',
                gap: '10px'
              }}>
                <BoxCheck checked={data.addressType === 'RESIDENCE'} label="Residence" />
                <BoxCheck checked={data.addressType === 'OFFICE'} label="Office" />
                <i style={{ marginLeft: '5px' }}>(select one)</i>
              </div>

              <AddressLine label="Flat/Door/Building" value={text.flat} />
              <AddressLine label="Road/Street/Block/Sector" value={text.road} />
              <AddressLine label="Post Office" value={text.postOffice} />
              <AddressLine label="Area/Locality/Town/City" value={text.area} />
              <AddressLine label="District" value={text.district} />

              <div style={{
                display: 'grid',
                gridTemplateColumns: '135px 107px 110px 120px 90px 1fr',
                alignItems: 'center',
                height: '21px'
              }}>
                <span style={{ fontSize: '9px' }}>State/Union Territory</span>
                <div style={{
                  border: '1px solid #888',
                  height: '19px',
                  boxSizing: 'border-box',
                  padding: '2px',
                  overflow: 'hidden',
                  fontSize: '8px',
                  fontWeight: 'bold'
                }}>
                  {String(text.state || '').toUpperCase()}
                </div>
                <span style={{ fontSize: '9px', textAlign: 'center' }}>Country/Region</span>
                <div style={{
                  border: '1px solid #888',
                  height: '19px',
                  boxSizing: 'border-box',
                  padding: '2px',
                  overflow: 'hidden',
                  fontSize: '8px',
                  fontWeight: 'bold'
                }}>
                  {String(text.country || 'INDIA').toUpperCase()}
                </div>
                <span style={{ fontSize: '9px', textAlign: 'center' }}>PIN / ZIP CODE</span>
                {renderLetterBoxes(text.pincode, 6, '18px', '18px', '10px')}
              </div>
            </div>
          </div>

          {/* ------------------------------ 5 PASSPORT --------------------- */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '43px 43px 1fr',
            minHeight: '27px',
            borderLeft: '1.2px solid #666',
            borderRight: '1.2px solid #666',
            borderBottom: '1px solid #aaa',
            boxSizing: 'border-box'
          }}>
            <RowNumber>5.</RowNumber>
            <TickColumn checked={selected.passport} />
            <div style={{
              display: 'flex',
              alignItems: 'center',
              padding: '0 7px',
              gap: '10px'
            }}>
              <strong style={{ width: '160px' }}>Passport Number</strong>
              {renderLetterBoxes(text.passport, 15, '18px', '18px', '10px')}
            </div>
          </div>

          {/* ------------------------------ 6 TIN -------------------------- */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '43px 43px 1fr',
            minHeight: '27px',
            borderLeft: '1.2px solid #666',
            borderRight: '1.2px solid #666',
            borderBottom: '1px solid #aaa',
            boxSizing: 'border-box'
          }}>
            <RowNumber>6.</RowNumber>
            <TickColumn checked={selected.tin} />
            <div style={{
              display: 'flex',
              alignItems: 'center',
              padding: '0 7px',
              gap: '8px'
            }}>
              <strong style={{ width: '215px' }}>
                Taxpayer Identification Number in the Country of Residence
              </strong>
              {renderLetterBoxes(text.tin, 20, '18px', '18px', '10px')}
            </div>
          </div>

          {/* ------------------------------ 7 CONTACT ---------------------- */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '43px 43px 1fr',
            minHeight: '86px',
            borderLeft: '1.2px solid #666',
            borderRight: '1.2px solid #666',
            borderBottom: '1px solid #aaa',
            boxSizing: 'border-box'
          }}>
            <RowNumber>7.</RowNumber>
            <TickColumn checked={selected.contact} />
            <div style={{ padding: '3px 7px', boxSizing: 'border-box' }}>
              <strong style={{ display: 'block', marginBottom: '4px' }}>Contact Details</strong>

              <div style={{
                display: 'flex',
                alignItems: 'center',
                height: '23px',
                gap: '6px'
              }}>
                <span style={{ width: '120px' }}>(i) Mobile Number</span>
                <span>Country Code</span>
                {renderLetterBoxes(text.countryCode, 2, '18px', '18px', '10px')}
                <span style={{ marginLeft: '10px' }}>Mobile Number</span>
                {renderLetterBoxes(text.mobile, 10, '18px', '18px', '10px')}
              </div>

              <div style={{
                display: 'flex',
                alignItems: 'center',
                height: '23px',
                gap: '6px'
              }}>
                <span style={{ width: '120px' }}>(ii) Email ID</span>
                <div style={{
                  border: '1px solid #888',
                  width: '450px',
                  height: '18px',
                  boxSizing: 'border-box',
                  padding: '2px 4px',
                  fontSize: '8px',
                  overflow: 'hidden'
                }}>
                  {text.email}
                </div>
              </div>

              <div style={{
                display: 'flex',
                alignItems: 'center',
                height: '23px',
                gap: '6px'
              }}>
                <span style={{ width: '120px' }}>
                  (iii) Landline No. with Country/ISD Code<br/>
                  and Area/STD Code <i>(if any)</i>
                </span>
                <span>Country/ISD Code</span>
                {renderLetterBoxes(text.isdCode, 2, '18px', '18px', '10px')}
                <span>Area/STD Code</span>
                {renderLetterBoxes(text.stdCode, 2, '18px', '18px', '10px')}
                <span>Landline Number</span>
                {renderLetterBoxes(text.landline, 10, '18px', '18px', '10px')}
              </div>
            </div>
          </div>

          {/* ---------------------- PART B HEADER -------------------------- */}
          <div style={{
            height: '25px',
            border: '1.2px solid #666',
            borderTop: 'none',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontWeight: 'bold',
            fontSize: '9.5px',
            boxSizing: 'border-box'
          }}>
            PART B - Details of Parents
          </div>

          {/* ------------------------------ 8 FATHER ----------------------- */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '43px 43px 1fr',
            minHeight: '61px',
            borderLeft: '1.2px solid #666',
            borderRight: '1.2px solid #666',
            borderBottom: '1px solid #aaa',
            boxSizing: 'border-box'
          }}>
            <RowNumber>8.</RowNumber>
            <TickColumn checked={selected.father} />
            <div style={{ padding: '3px 5px' }}>
              <NameLine label="Father's First Name" value={text.fatherFirstName} />
              <NameLine label="Father's Middle Name" value={text.fatherMiddleName} />
              <NameLine label="Father's Last Name" value={text.fatherLastName} />
            </div>
          </div>

          {/* ------------------------------ 9 MOTHER ----------------------- */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '43px 43px 1fr',
            minHeight: '61px',
            borderLeft: '1.2px solid #666',
            borderRight: '1.2px solid #666',
            borderBottom: '1px solid #aaa',
            boxSizing: 'border-box'
          }}>
            <RowNumber>9.</RowNumber>
            <TickColumn checked={selected.mother} />
            <div style={{ padding: '3px 5px' }}>
              <NameLine label="Mother's First Name" value={text.motherFirstName} />
              <NameLine label="Mother's Middle Name" value={text.motherMiddleName} />
              <NameLine label="Mother's Last Name" value={text.motherLastName} />
            </div>
          </div>

          {/* ------------------------- 10 PARENT TO PRINT ------------------ */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '43px 43px 1fr',
            height: '27px',
            borderLeft: '1.2px solid #666',
            borderRight: '1.2px solid #666',
            borderBottom: '1px solid #aaa',
            boxSizing: 'border-box'
          }}>
            <RowNumber>10.</RowNumber>
            <TickColumn checked={selected.parentPrint} />
            <div style={{
              display: 'flex',
              alignItems: 'center',
              padding: '0 5px',
              gap: '15px'
            }}>
              <strong>Name of parent to be printed on Permanent Account Number card <i>(select one)</i></strong>
              <BoxCheck checked={data.parentNameToPrint === 'FATHER'} label="Father" />
              <BoxCheck checked={data.parentNameToPrint === 'MOTHER'} label="Mother" />
            </div>
          </div>

          {/* Page number */}
          <div style={{
            textAlign: 'right',
            fontSize: '8px',
            marginTop: '3px',
            paddingRight: '4px'
          }}>
            1 of 2
          </div>
        </div>
      </div>

      {/* =====================================================================
          PAGE 2 - PART C & VERIFICATION & DECLARATION
          ===================================================================== */}
      <div
        id="pancr-pdf-container-page2"
        style={{
          width: '794px',
          height: '1123px',
          padding: '14px 15px',
          background: '#fff',
          color: '#000',
          fontFamily: 'Arial, sans-serif',
          fontSize: '9px',
          boxSizing: 'border-box',
          lineHeight: '1.2',
          overflow: 'hidden'
        }}
      >
        <div style={{
          border: '2px solid #666',
          height: '1095px',
          padding: '7px',
          boxSizing: 'border-box',
          overflow: 'hidden'
        }}>
          {/* ---------------------- PART C HEADER -------------------------- */}
          <div style={{
            height: '25px',
            border: '1.2px solid #666',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontWeight: 'bold',
            fontSize: '9px',
            boxSizing: 'border-box'
          }}>
            Part C: Declaration by Applicant or by Representative Assessee on behalf of the Applicant
          </div>

          {/* ------------------------------ 11 DOCUMENTS ------------------- */}
          <div style={{
            borderLeft: '1.2px solid #666',
            borderRight: '1.2px solid #666',
            borderBottom: '1.2px solid #666',
            minHeight: '70px',
            boxSizing: 'border-box',
            marginBottom: '4px'
          }}>
            <div style={{
              display: 'grid',
              gridTemplateColumns: '43px 43px 1fr',
              minHeight: '28px'
            }}>
              <RowNumber>11.</RowNumber>
              <TickColumn checked={selected.proofChange || selected.copyPan} />
              <div style={{
                background: '#e6e6e6',
                padding: '4px 5px',
                fontWeight: 'bold',
                fontSize: '8.5px',
                boxSizing: 'border-box'
              }}>
                Documents submitted as Proof of Identity, Proof of Address, Proof of Date of Birth of the Applicant &amp; Proof of Change in support of proposed changes / corrections requested by the Applicant
              </div>
            </div>

            <div style={{
              display: 'flex',
              flexWrap: 'wrap',
              alignItems: 'center',
              gap: '18px',
              padding: '4px 10px 3px 88px',
              boxSizing: 'border-box',
              fontSize: '8.5px'
            }}>
              <BoxCheck checked={Boolean(data.proofOfIdentity)} label="(i) Proof of Identity" />
              <BoxCheck checked={Boolean(data.proofOfAddress)} label="(ii) Proof of Address" />
              <BoxCheck checked={Boolean(data.proofOfDob)} label="(iii) Proof of Date of Birth" />
            </div>

            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '28px',
              padding: '1px 10px 5px 88px',
              boxSizing: 'border-box',
              fontSize: '8.5px'
            }}>
              <BoxCheck checked={selected.proofChange} label="(iv) Documentary proof in support of other changes" />
              <BoxCheck checked={selected.copyPan} label="(v) Copy of PAN" />
            </div>
          </div>
          <div style={{
            border: '1.2px solid #666',
            height: '233px',
            boxSizing: 'border-box'
          }}>
            <div style={{
              height: '25px',
              borderBottom: '1.2px solid #666',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: 'bold',
              fontSize: '10px',
              fontStyle: 'italic',
              boxSizing: 'border-box'
            }}>
              Verification &amp; Declaration
            </div>

            <div style={{
              padding: '22px 22px 0',
              fontSize: '9px',
              lineHeight: '1.35',
              boxSizing: 'border-box'
            }}>
              <div>
                a. I , <span style={{
                  display: 'inline-block',
                  minWidth: '225px',
                  borderBottom: '1px dotted #555',
                  fontWeight: 'bold'
                }}>
                  {(fullNameStr || data.lastName || '').toUpperCase()}
                </span>
                , in the capacity of <span style={{
                  display: 'inline-block',
                  minWidth: '165px',
                  borderBottom: '1px dotted #555'
                }}>
                  {data.representativeCapacity || 'Self'}
                </span>
                (Self/Representative Assessee) do hereby declare that
              </div>

              <div style={{ marginTop: '2px' }}>
                what is stated above is true to the best of my knowledge and belief.
              </div>

              <div style={{
                marginTop: '25px',
                fontSize: '9px'
              }}>
                Place<span style={{ marginLeft: '5px' }}>………</span>
                <span style={{
                  marginLeft: '130px'
                }}>
                  {data.district ? String(data.district).toUpperCase() : ''}
                </span>
              </div>

              <div style={{
                marginTop: '20px',
                fontSize: '9px'
              }}>
                Date<span style={{ marginLeft: '5px' }}>….........</span>
                <span style={{ marginLeft: '75px' }}>
                  {dayStr}/{monthStr}/{yearStr}
                </span>
              </div>

              <div style={{
                position: 'relative',
                marginTop: '-13px',
                marginLeft: '375px',
                width: '230px',
                textAlign: 'center'
              }}>
                <div style={{
                  width: '230px',
                  height: '78px',
                  border: '1.2px solid #777',
                  boxSizing: 'border-box',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  background: '#fff'
                }}>
                  {data.signatureUrl ? (
                    <img
                      src={data.signatureUrl}
                      alt="Signature"
                      style={{
                        maxWidth: '215px',
                        maxHeight: '68px',
                        objectFit: 'contain'
                      }}
                    />
                  ) : null}
                </div>

                <div style={{
                  fontSize: '8px',
                  marginTop: '9px',
                  lineHeight: '1.2'
                }}>
                  (Signature / Left Hand Thumb Impression of Applicant or Representative Assessee)
                </div>
              </div>
            </div>
          </div>

          <div style={{
            textAlign: 'right',
            fontSize: '8px',
            marginTop: '4px',
            paddingRight: '4px'
          }}>
            2 of 2
          </div>
        </div>
      </div>

    </div>
  );
};

/* =====================================================================
   PAGE 1 ONLY - NON-INDIVIDUAL PAN CORRECTION FORM
   (Firm, Trust, Company, HUF, BOI, AOP, Local Authority, AJP, Govt, LLP)
   ===================================================================== */
const FormPanCrNonIndividualPdfTemplate = ({ data = {} }) => {
  const today = new Date();
  const dayStr = String(today.getDate()).padStart(2, '0');
  const monthStr = String(today.getMonth() + 1).padStart(2, '0');
  const yearStr = String(today.getFullYear());

  // Date of Incorporation parsing
  const targetDob = data.dateOfIncorporation || data.dob;
  let dobDay = '', dobMonth = '', dobYear = '';
  if (targetDob) {
    const str = String(targetDob).trim();
    if (str.includes('-')) {
      const parts = str.split('-');
      if (parts[0].length === 4) {
        dobYear = parts[0];
        dobMonth = parts[1];
        dobDay = parts[2];
      } else {
        dobDay = parts[0];
        dobMonth = parts[1];
        dobYear = parts[2];
      }
    } else if (str.includes('/')) {
      const parts = str.split('/');
      if (parts[0].length === 4) {
        dobYear = parts[0];
        dobMonth = parts[1];
        dobDay = parts[2];
      } else {
        dobDay = parts[0];
        dobMonth = parts[1];
        dobYear = parts[2];
      }
    }
  }

  const entityName = (data.entityName || data.applicantName || data.lastName || data.nameAsPerAadhaar || '').toUpperCase();
  const address = data.officeAddress || data.address || data.residenceAddress || {};
  const panNo = (data.panNumber || data.pan || '').toUpperCase();
  const regNo = (data.registrationNumber || data.cin || data.llpin || '').toUpperCase();

  const selected = {
    name: Boolean(data.nameCorrection ?? data.changeName),
    dob: Boolean(data.dobCorrection ?? data.changeDob),
    address: Boolean(data.addressCorrection ?? data.changeAddress),
    tin: Boolean(data.tinCorrection ?? data.changeTin),
    contact: Boolean(data.contactCorrection ?? data.changeContact),
  };

  const RowNumber = ({ children }) => (
    <div style={{
      width: '43px',
      flex: '0 0 43px',
      minHeight: '20px',
      background: '#e9e9e9',
      borderRight: '1px solid #aaa',
      display: 'flex',
      alignItems: 'center',
      paddingLeft: '6px',
      boxSizing: 'border-box',
      fontWeight: 'bold',
      fontSize: '9px'
    }}>
      {children}
    </div>
  );

  const TickColumn = ({ checked }) => (
    <div style={{
      width: '43px',
      flex: '0 0 43px',
      minHeight: '20px',
      background: '#e9e9e9',
      borderRight: '1px solid #aaa',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxSizing: 'border-box'
    }}>
      <BoxCheck checked={checked} />
    </div>
  );

  const AddressLine = ({ label, value }) => (
    <div style={{
      display: 'grid',
      gridTemplateColumns: '130px 1fr',
      alignItems: 'center',
      height: '20px',
      marginBottom: '2px'
    }}>
      <span style={{ fontSize: '9px' }}>{label}</span>
      {renderLetterBoxes(value, 25, '20px', '19px', '11px')}
    </div>
  );

  const SmallBoxes = ({ value = '', length = 2, width = '18px' }) =>
    renderLetterBoxes(value, length, width, '18px', '10px');

  return (
    <div
      id="pancr-pdf-container"
      style={{
        display: 'none',
        position: 'absolute',
        left: '-9999px',
        top: '-9999px'
      }}
    >
      {/* 1 PAGE ONLY FOR NON-INDIVIDUAL CORRECTION FORM */}
      <div
        id="pancr-pdf-container-page1"
        style={{
          width: '794px',
          height: '1123px',
          padding: '14px 15px',
          background: '#fff',
          color: '#000',
          fontFamily: 'Arial, sans-serif',
          fontSize: '9px',
          boxSizing: 'border-box',
          lineHeight: '1.15',
          overflow: 'hidden'
        }}
      >
        <div style={{
          border: '2px solid #666',
          height: '1095px',
          padding: '7px',
          boxSizing: 'border-box',
          overflow: 'hidden'
        }}>

          {/* HEADER */}
          <div style={{ textAlign: 'center', marginBottom: '8px' }}>
            <div style={{ fontSize: '12px', fontWeight: 'bold', marginBottom: '2px' }}>
              Request For Changes Or Correction in PAN Data
            </div>
            <div style={{ fontSize: '10px', fontWeight: 'bold', marginBottom: '8px' }}>
              [For Non-Individual]
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '5px' }}>
              <div>
                <span style={{ fontSize: '8.5px', fontWeight: 'bold', display: 'block', marginBottom: '2px' }}>
                  Permanent Account Number (PAN)
                </span>
                {renderLetterBoxes(panNo, 10, '19px', '19px', '11px')}
              </div>

              <div style={{ marginTop: '2px' }}>
                <span style={{ fontSize: '8.5px', fontWeight: 'bold', display: 'block', marginBottom: '2px' }}>
                  Registration Number
                </span>
                {renderLetterBoxes(regNo, 16, '18px', '18px', '10px')}
              </div>
            </div>
          </div>

          {/* TABLE HEADER */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '43px 43px 1fr',
            height: '24px',
            border: '1.2px solid #666',
            boxSizing: 'border-box',
            fontWeight: 'bold',
            fontSize: '9px'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', borderRight: '1px solid #777' }}>
              Sr. No.
            </div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', borderRight: '1px solid #777', textAlign: 'center' }}>
              Tick<br/>Box
            </div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              Part A - Personal Information
            </div>
          </div>

          {/* 1. Name */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '43px 43px 1fr',
            borderLeft: '1.2px solid #666',
            borderRight: '1.2px solid #666',
            borderBottom: '1px solid #aaa',
            minHeight: '60px',
            boxSizing: 'border-box'
          }}>
            <RowNumber>1.</RowNumber>
            <TickColumn checked={selected.name} />
            <div style={{ padding: '4px 5px', boxSizing: 'border-box' }}>
              <div style={{ fontWeight: 'bold', marginBottom: '4px' }}>Name</div>
              {renderLetterBoxes(entityName.slice(0, 30), 30, '16.5px', '18px', '10px')}
              {entityName.length > 30 && (
                <div style={{ marginTop: '2px' }}>
                  {renderLetterBoxes(entityName.slice(30, 60), 30, '16.5px', '18px', '10px')}
                </div>
              )}
            </div>
          </div>

          {/* 2. Date of Incorporation */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '43px 43px 1fr',
            minHeight: '27px',
            borderLeft: '1.2px solid #666',
            borderRight: '1.2px solid #666',
            borderBottom: '1px solid #aaa',
            boxSizing: 'border-box'
          }}>
            <RowNumber>2.</RowNumber>
            <TickColumn checked={selected.dob} />
            <div style={{ display: 'flex', alignItems: 'center', padding: '0 7px', gap: '4px', fontSize: '7.8px' }}>
              <strong style={{ width: '340px', lineHeight: '1.1' }}>
                Date of Incorporation/Agreement/Partnership or Trust Deed/Formation of Body of Individuals or Association of Persons
              </strong>
              <span>DD</span>
              {SmallBoxes({ value: dobDay, length: 2 })}
              <span style={{ marginLeft: '4px' }}>MM</span>
              {SmallBoxes({ value: dobMonth, length: 2 })}
              <span style={{ marginLeft: '4px' }}>YYYY</span>
              {SmallBoxes({ value: dobYear, length: 4 })}
            </div>
          </div>

          {/* 3. Office Address */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '43px 43px 1fr',
            borderLeft: '1.2px solid #666',
            borderRight: '1.2px solid #666',
            borderBottom: '1px solid #aaa',
            minHeight: '145px',
            boxSizing: 'border-box'
          }}>
            <RowNumber>3.</RowNumber>
            <TickColumn checked={selected.address} />
            <div style={{ padding: '3px 5px', boxSizing: 'border-box' }}>
              <strong style={{ display: 'block', marginBottom: '3px' }}>Office Address</strong>
              <AddressLine label="Flat/Door/Building" value={address.flatDoorBuilding || address.flatNo || ''} />
              <AddressLine label="Road/Street/Block/Sector" value={address.roadStreetBlock || address.roadStreet || ''} />
              <AddressLine label="Post Office" value={address.postOffice || ''} />
              <AddressLine label="Area/Locality/Town/City" value={address.areaLocality || address.areaTaluka || ''} />
              <AddressLine label="District" value={address.district || ''} />

              <div style={{
                display: 'grid',
                gridTemplateColumns: '135px 107px 110px 120px 90px 1fr',
                alignItems: 'center',
                height: '21px'
              }}>
                <span style={{ fontSize: '9px' }}>State/Union Territory</span>
                <div style={{ border: '1px solid #888', height: '19px', padding: '2px', fontSize: '8px', fontWeight: 'bold' }}>
                  {String(address.state || '').toUpperCase()}
                </div>
                <span style={{ fontSize: '9px', textAlign: 'center' }}>Country/Region</span>
                <div style={{ border: '1px solid #888', height: '19px', padding: '2px', fontSize: '8px', fontWeight: 'bold' }}>
                  {String(address.country || 'INDIA').toUpperCase()}
                </div>
                <span style={{ fontSize: '9px', textAlign: 'center' }}>PIN / ZIP CODE</span>
                {renderLetterBoxes(address.pincode || '', 6, '18px', '18px', '10px')}
              </div>
            </div>
          </div>

          {/* 4. TIN */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '43px 43px 1fr',
            minHeight: '27px',
            borderLeft: '1.2px solid #666',
            borderRight: '1.2px solid #666',
            borderBottom: '1px solid #aaa',
            boxSizing: 'border-box'
          }}>
            <RowNumber>4.</RowNumber>
            <TickColumn checked={selected.tin} />
            <div style={{ display: 'flex', alignItems: 'center', padding: '0 7px', gap: '8px' }}>
              <strong style={{ width: '260px' }}>
                Taxpayer Identification Number in the country of residence
              </strong>
              {renderLetterBoxes(data.tin || '', 20, '18px', '18px', '10px')}
            </div>
          </div>

          {/* 5. Contact Details */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '43px 43px 1fr',
            minHeight: '80px',
            borderLeft: '1.2px solid #666',
            borderRight: '1.2px solid #666',
            borderBottom: '1px solid #aaa',
            boxSizing: 'border-box'
          }}>
            <RowNumber>5.</RowNumber>
            <TickColumn checked={selected.contact} />
            <div style={{ padding: '3px 7px', boxSizing: 'border-box' }}>
              <strong style={{ display: 'block', marginBottom: '3px' }}>Contact Details</strong>

              <div style={{ display: 'flex', alignItems: 'center', height: '22px', gap: '6px' }}>
                <span style={{ width: '120px' }}>(i) Mobile Number</span>
                <span>Country Code</span>
                {renderLetterBoxes(data.countryCode || '91', 2, '18px', '18px', '10px')}
                <span style={{ marginLeft: '10px' }}>Mobile Number</span>
                {renderLetterBoxes(data.mobileNumber || data.mobile || '', 10, '18px', '18px', '10px')}
              </div>

              <div style={{ display: 'flex', alignItems: 'center', height: '22px', gap: '6px' }}>
                <span style={{ width: '120px' }}>(ii) Email ID</span>
                <div style={{ border: '1px solid #888', width: '450px', height: '18px', padding: '2px 4px', fontSize: '8px' }}>
                  {data.email || ''}
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', height: '22px', gap: '6px' }}>
                <span style={{ width: '120px' }}>
                  (iii) Landline No. with Country/ISD Code and Area/STD Code (if any)
                </span>
                <span>Country/ISD Code</span>
                {renderLetterBoxes(data.countryCode || '91', 2, '18px', '18px', '10px')}
                <span>Area/STD Code</span>
                {renderLetterBoxes(data.stdCode || '', 5, '18px', '18px', '10px')}
                <span>Landline Number</span>
                {renderLetterBoxes(data.landlineNumber || '', 10, '18px', '18px', '10px')}
              </div>
            </div>
          </div>

          {/* PART B - Declaration by Applicant */}
          <div style={{
            height: '24px',
            borderLeft: '1.2px solid #666',
            borderRight: '1.2px solid #666',
            borderBottom: '1.2px solid #666',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontWeight: 'bold',
            fontSize: '9.5px',
            boxSizing: 'border-box'
          }}>
            PART B - Declaration by Applicant
          </div>

          {/* 6. Documents submitted */}
          <div style={{
            borderLeft: '1.2px solid #666',
            borderRight: '1.2px solid #666',
            borderBottom: '1.2px solid #666',
            padding: '6px 8px',
            boxSizing: 'border-box'
          }}>
            <div style={{ fontWeight: 'bold', fontSize: '8.2px', marginBottom: '6px' }}>
              6. Documents submitted as Proof of Identity, Proof of Address, Proof of Date of Incorporation/Agreement/Partnership or Trust Deed/Formation of Body of Individuals or Association of Persons of the Applicant
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px 20px', paddingLeft: '20px', fontSize: '8.5px' }}>
              <BoxCheck checked={Boolean(data.proofOfIdentity)} label="(i) Proof of Identity" />
              <BoxCheck checked={Boolean(data.proofOfAddress)} label="(ii) Proof of Address" />
              <BoxCheck checked={Boolean(data.proofOfDob || data.proofOfIncorporation)} label="(iii) Proof of Date of Incorporation/Agreement/Partnership or Trust Deed/Formation of Body of Individuals or Association of Persons" />
              <BoxCheck checked={Boolean(data.copyOfPan || data.panCopy)} label="(iv) Proof of PAN" />
            </div>
          </div>

          {/* VERIFICATION & DECLARATION BOX */}
          <div style={{
            borderLeft: '1.2px solid #666',
            borderRight: '1.2px solid #666',
            borderBottom: '1.2px solid #666',
            height: '210px',
            boxSizing: 'border-box',
            padding: '10px 14px'
          }}>
            <div style={{ textAlign: 'center', fontWeight: 'bold', fontSize: '10px', fontStyle: 'italic', marginBottom: '10px' }}>
              Verification &amp; Declaration
            </div>

            <div style={{ fontSize: '8.8px', lineHeight: '1.4' }}>
              <div>
                a. I, <span style={{ display: 'inline-block', minWidth: '200px', borderBottom: '1px dotted #555', fontWeight: 'bold' }}>
                  {(data.verifierName || data.raName || entityName).toUpperCase()}
                </span>
                , in the capacity of <span style={{ display: 'inline-block', minWidth: '150px', borderBottom: '1px dotted #555', fontWeight: 'bold' }}>
                  {data.representativeCapacity || 'Authorized Representative'}
                </span> do hereby declare that what is stated above is true to the best of my knowledge and belief.
              </div>

              <div style={{ marginTop: '14px' }}>
                Designation <span style={{ borderBottom: '1px dotted #555', paddingRight: '120px' }}>{data.designation || ''}</span>
              </div>
              <div style={{ marginTop: '8px' }}>
                Place <span style={{ borderBottom: '1px dotted #555', paddingRight: '140px' }}>{data.district ? String(data.district).toUpperCase() : ''}</span>
              </div>
              <div style={{ marginTop: '8px' }}>
                Date <span style={{ borderBottom: '1px dotted #555', paddingRight: '100px' }}>{dayStr}/{monthStr}/{yearStr}</span>
              </div>

              <div style={{
                position: 'relative',
                marginTop: '-55px',
                marginLeft: '375px',
                width: '230px',
                textAlign: 'center'
              }}>
                <div style={{
                  width: '230px',
                  height: '75px',
                  border: '1.2px solid #777',
                  boxSizing: 'border-box',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  background: '#fff'
                }}>
                  {data.signatureUrl ? (
                    <img
                      src={data.signatureUrl}
                      alt="Signature"
                      style={{
                        maxWidth: '215px',
                        maxHeight: '65px',
                        objectFit: 'contain'
                      }}
                    />
                  ) : null}
                </div>

                <div style={{ fontSize: '7.5px', marginTop: '6px', lineHeight: '1.15' }}>
                  (Signature / Left Hand Thumb Impression of Applicant or Representative Assessee or Authorized Representative)
                </div>
              </div>
            </div>
          </div>

          <div style={{ textAlign: 'right', fontSize: '8px', marginTop: '3px', paddingRight: '4px' }}>
            1 of 2
          </div>

        </div>
      </div>
    </div>
  );
};

const MainPanCrPdfTemplate = ({ data = {} }) => {
  const isIndividual = !data.category || data.category === 'INDIVIDUAL';
  if (isIndividual) {
    return <Form49APdfTemplate data={data} />;
  }
  return <FormPanCrNonIndividualPdfTemplate data={data} />;
};

export default MainPanCrPdfTemplate;

export const generatePANCR01Pdf = generateForm49APdf;
export const generatePanCrPdf = generateForm49APdf;
