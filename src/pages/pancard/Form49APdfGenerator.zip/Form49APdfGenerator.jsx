import React from 'react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

/*
 * FORM NO. 93 - Individual / Citizen of India
 * --------------------------------------------
 * This version keeps the same generation approach as the old code:
 * React HTML -> html2canvas -> jsPDF.
 *
 * Important:
 * - The page is built in millimetres, not arbitrary browser pixels.
 * - A4 = 210mm x 297mm.
 * - The layout below is based on the supplied Form No. 93 first two pages.
 * - Character cells are sized in mm so their position does not depend on
 *   the browser/device pixel density.
 */

const A4 = {
  width: 210,
  height: 297,
  border: 1.1,
};

const OUTER = {
  left: 5.2,
  right: 5.2,
  top: 4.8,
  bottom: 4.8,
};

const BoxGrid = ({
  value = '',
  length = 25,
  width = 5.45,
  height = 5.05,
  fontSize = 7.2,
  uppercase = true,
}) => {
  const text = String(value ?? '');
  const chars = (uppercase ? text.toUpperCase() : text)
    .padEnd(length, ' ')
    .slice(0, length)
    .split('');

  return (
    <div
      style={{
        display: 'flex',
        flexWrap: 'nowrap',
        width: `${width * length}mm`,
        height: `${height}mm`,
        overflow: 'hidden',
      }}
    >
      {chars.map((ch, i) => (
        <div
          key={i}
          style={{
            flex: `0 0 ${width}mm`,
            width: `${width}mm`,
            height: `${height}mm`,
            border: '0.28mm solid #777',
            borderLeft: i === 0 ? '0.28mm solid #777' : 'none',
            boxSizing: 'border-box',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontFamily: 'Arial, sans-serif',
            fontSize: `${fontSize}pt`,
            fontWeight: 'bold',
            lineHeight: 1,
            color: '#111',
            background: '#fff',
          }}
        >
          {ch !== ' ' ? ch : ''}
        </div>
      ))}
    </div>
  );
};

const Check = ({ checked = false, label = '', italic = false }) => (
  <span
    style={{
      display: 'inline-flex',
      alignItems: 'center',
      gap: '1.1mm',
      whiteSpace: 'nowrap',
      fontSize: '7.1pt',
      fontStyle: italic ? 'italic' : 'normal',
    }}
  >
    <span
      style={{
        width: '4.2mm',
        height: '4.2mm',
        border: '0.3mm solid #888',
        boxSizing: 'border-box',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: '7pt',
        fontWeight: 'bold',
        lineHeight: 1,
      }}
    >
      {checked ? '✓' : ''}
    </span>
    {label}
  </span>
);

const GreyBar = ({ children, style = {} }) => (
  <div
    style={{
      background: '#e7e7e7',
      borderTop: '0.25mm solid #d1d1d1',
      borderBottom: '0.25mm solid #d1d1d1',
      minHeight: '6mm',
      padding: '1.0mm 2mm',
      boxSizing: 'border-box',
      fontWeight: 'bold',
      fontSize: '7.5pt',
      ...style,
    }}
  >
    {children}
  </div>
);

const CellRow = ({
  label,
  value = '',
  length = 25,
  labelWidth = 53,
  boxWidth = 5.45,
  boxHeight = 5.05,
  labelFont = 7.1,
  marginBottom = 0.55,
}) => (
  <div
    style={{
      display: 'flex',
      alignItems: 'center',
      marginBottom: `${marginBottom}mm`,
      minHeight: `${boxHeight}mm`,
    }}
  >
    <div
      style={{
        width: `${labelWidth}mm`,
        flex: `0 0 ${labelWidth}mm`,
        paddingLeft: '2mm',
        fontSize: `${labelFont}pt`,
        lineHeight: 1.05,
        boxSizing: 'border-box',
      }}
    >
      {label}
    </div>
    <BoxGrid
      value={value}
      length={length}
      width={boxWidth}
      height={boxHeight}
    />
  </div>
);

const FullWidthLine = ({ children, style = {} }) => (
  <div
    style={{
      borderTop: '0.25mm solid #777',
      ...style,
    }}
  >
    {children}
  </div>
);

const SectionTitle = ({ children }) => (
  <div
    style={{
      height: '6mm',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      border: '0.3mm solid #444',
      background: '#fff',
      fontSize: '8.1pt',
      fontWeight: 'bold',
      boxSizing: 'border-box',
      textAlign: 'center',
    }}
  >
    {children}
  </div>
);

const Page = ({ id, children }) => (
  <div
    id={id}
    style={{
      width: `${A4.width}mm`,
      height: `${A4.height}mm`,
      background: '#fff',
      color: '#111',
      fontFamily: 'Arial, Helvetica, sans-serif',
      boxSizing: 'border-box',
      overflow: 'hidden',
      position: 'relative',
      fontSize: '7.5pt',
      lineHeight: 1.12,
    }}
  >
    <div
      style={{
        position: 'absolute',
        left: `${OUTER.left}mm`,
        top: `${OUTER.top}mm`,
        width: `${A4.width - OUTER.left - OUTER.right}mm`,
        height: `${A4.height - OUTER.top - OUTER.bottom}mm`,
        border: '1.05mm solid #555',
        boxSizing: 'border-box',
        padding: '1.8mm',
        overflow: 'hidden',
      }}
    >
      {children}
    </div>
    <div
      style={{
        position: 'absolute',
        right: '8mm',
        bottom: '6mm',
        fontSize: '6.5pt',
      }}
    >
      {id.endsWith('page1') ? '1 of 5' : '2 of 5'}
    </div>
  </div>
);

export const generateForm93Pdf = async (
  data = {},
  elementId = 'form93-pdf-container'
) => {
  const element = document.getElementById(elementId);

  if (!element) {
    console.error('Form 93 container element not found');
    return false;
  }

  const originalDisplay = element.style.display;
  element.style.display = 'block';

  try {
    const page1 = document.getElementById(`${elementId}-page1`);
    const page2 = document.getElementById(`${elementId}-page2`);

    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
      compress: true,
    });

    const renderPage = async (page, first = false) => {
      if (!page) return;

      const canvas = await html2canvas(page, {
        scale: 3,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff',
        logging: false,
        width: 794,
        windowWidth: 794,
      });

      const image = canvas.toDataURL('image/jpeg', 0.98);

      if (!first) pdf.addPage();
      pdf.addImage(image, 'JPEG', 0, 0, A4.width, A4.height, undefined, 'FAST');
    };

    await renderPage(page1, true);
    await renderPage(page2, false);

    const safeName = (
      data.lastName ||
      data.nameAsPerAadhaar ||
      data.firstName ||
      'Application'
    )
      .toString()
      .replace(/[^\w-]+/g, '_');

    const pdfBlob = pdf.output('blob');
    const blobUrl = URL.createObjectURL(pdfBlob);
    const pdfWindow = window.open(blobUrl, '_blank');
    if (!pdfWindow) {
      pdf.save(`PAN_Form_93_${safeName}.pdf`);
    }
    return true;
  } catch (err) {
    console.error('Error generating Form 93 PDF:', err);
    return false;
  } finally {
    element.style.display = originalDisplay;
  }
};

const PhotoBox = ({ photoUrl, signatureUrl, left = false }) => (
  <div
    style={{
      width: '35mm',
      height: '45mm',
      border: '0.35mm solid #555',
      boxSizing: 'border-box',
      position: 'relative',
      background: '#fff',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      overflow: 'visible',
    }}
  >
    {photoUrl ? (
      <img
        src={photoUrl}
        alt="Applicant"
        style={{
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          display: 'block',
        }}
      />
    ) : (
      <div
        style={{
          textAlign: 'center',
          width: '31mm',
          fontSize: '6.5pt',
          lineHeight: 1.25,
          color: '#222',
        }}
      >
        Recent colour
        <br />
        photograph of the applicant
        <br />
        (4.5 cm x 3.5 cm)
        {left && (
          <>
            <br />
            with Sign/Left thumb
            <br />
            impression across the photo of
            <br />
            the applicant
          </>
        )}
      </div>
    )}

    {left && signatureUrl && (
      <img
        src={signatureUrl}
        alt="Signature"
        style={{
          position: 'absolute',
          width: '30mm',
          height: '10mm',
          objectFit: 'contain',
          left: '2mm',
          bottom: '7mm',
          zIndex: 2,
        }}
      />
    )}
  </div>
);

const NameRows = ({ firstName, middleName, lastName, aadhaar = false }) => (
  <div>
    <CellRow label="First Name" value={firstName} length={aadhaar ? 30 : 25} />
    <CellRow label="Middle Name" value={middleName} length={aadhaar ? 30 : 25} />
    <CellRow label="Last Name" value={lastName} length={aadhaar ? 30 : 25} />
  </div>
);

const AddressRows = ({ address = {}, prefix = '' }) => {
  const flat = address[`${prefix}flatDoorBuilding`] || address.flatDoorBuilding || address[`${prefix}flatNo`] || address.flatNo || '';
  const road = address[`${prefix}roadStreetBlock`] || address.roadStreetBlock || address[`${prefix}roadStreet`] || address.roadStreet || '';
  const post = address[`${prefix}postOffice`] || address.postOffice || address[`${prefix}premises`] || address.premises || '';
  const area = address[`${prefix}areaLocality`] || address.areaLocality || address[`${prefix}areaTaluka`] || address.areaTaluka || '';
  const dist = address[`${prefix}district`] || address.district || '';
  const st = address[`${prefix}state`] || address.state || '';
  const pin = address[`${prefix}pincode`] || address.pincode || '';
  const ctry = address[`${prefix}country`] || address.country || 'INDIA';

  return (
    <div>
      <CellRow
        label="Flat/Door/Building"
        value={flat}
        length={30}
        labelWidth={53}
        boxWidth={4.55}
      />
      <CellRow
        label="Road/Street/Block/Sector"
        value={road}
        length={30}
        labelWidth={53}
        boxWidth={4.55}
      />
      <CellRow
        label="Post Office"
        value={post}
        length={30}
        labelWidth={53}
        boxWidth={4.55}
      />
      <CellRow
        label="Area/Locality/Town/City"
        value={area}
        length={30}
        labelWidth={53}
        boxWidth={4.55}
      />
      <CellRow
        label="District"
        value={dist}
        length={30}
        labelWidth={53}
        boxWidth={4.55}
      />

      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          minHeight: '5.05mm',
          marginBottom: '0.6mm',
          fontSize: '6.8pt',
        }}
      >
        <div
          style={{
            width: '38mm',
            flex: '0 0 38mm',
            paddingLeft: '2mm',
          }}
        >
          State/Union Territory
        </div>
        <div
          style={{
            width: '26mm',
            height: '5.05mm',
            border: '0.28mm solid #777',
            boxSizing: 'border-box',
            padding: '0.8mm 1mm',
            fontSize: '6.5pt',
            fontWeight: 'bold',
            textTransform: 'uppercase',
            overflow: 'hidden',
            whiteSpace: 'nowrap',
          }}
        >
          {st}
        </div>
        <div
          style={{
            marginLeft: '3mm',
            width: '23mm',
          }}
        >
          Country/Region
        </div>
        <div
          style={{
            width: '22mm',
            height: '5.05mm',
            border: '0.28mm solid #777',
            boxSizing: 'border-box',
            padding: '0.8mm 1mm',
            fontSize: '6.5pt',
            fontWeight: 'bold',
            textTransform: 'uppercase',
          }}
        >
          {ctry}
        </div>
        <div
          style={{
            marginLeft: '3mm',
            marginRight: '2mm',
            whiteSpace: 'nowrap',
          }}
        >
          PIN / ZIP CODE
        </div>
        <BoxGrid value={pin} length={6} width={4.4} height={5.05} />
      </div>
    </div>
  );
};

const Form93PdfTemplate = ({ data = {} }) => {
  const isIndividual = !data.category || data.category === 'INDIVIDUAL';
  const entityTitleName = data.entityName || (!isIndividual ? data.lastName : '');

  // 1. Name normalization
  const nameParts = (data.applicantName || data.nameAsPerAadhaar || '').trim().split(' ');
  const fName = isIndividual ? ((data.firstName !== undefined && data.firstName !== '') ? data.firstName : (nameParts.length > 1 ? nameParts[0] : nameParts[0] || '')) : '';
  const lName = isIndividual ? ((data.lastName !== undefined && data.lastName !== '') ? data.lastName : (nameParts.length > 1 ? nameParts[nameParts.length - 1] : '') || '') : (entityTitleName || data.applicantName || '');
  const mName = isIndividual ? ((data.middleName !== undefined && data.middleName !== '') ? data.middleName : (nameParts.length > 2 ? nameParts.slice(1, -1).join(' ') : '') || '') : '';

  const fullName = isIndividual ? `${fName} ${mName} ${lName}`.replace(/\s+/g, ' ').trim() : lName;
  const aadhaarName = (data.nameAsPerAadhaar || fullName).toUpperCase();

  // Father & Mother name normalization
  const fatherParts = (data.fatherName || '').trim().split(' ');
  const fatherFirstNameVal = data.fatherFirstName !== undefined && data.fatherFirstName !== '' ? data.fatherFirstName : (fatherParts.length > 1 ? fatherParts[0] : (fatherParts[0] || ''));
  const fatherLastNameVal = data.fatherLastName !== undefined && data.fatherLastName !== '' ? data.fatherLastName : (fatherParts.length > 1 ? fatherParts[fatherParts.length - 1] : '');
  const fatherMiddleNameVal = data.fatherMiddleName !== undefined && data.fatherMiddleName !== '' ? data.fatherMiddleName : (fatherParts.length > 2 ? fatherParts.slice(1, -1).join(' ') : '');

  const motherParts = (data.motherName || '').trim().split(' ');
  const motherFirstNameVal = data.motherFirstName !== undefined && data.motherFirstName !== '' ? data.motherFirstName : (motherParts.length > 1 ? motherParts[0] : (motherParts[0] || ''));
  const motherLastNameVal = data.motherLastName !== undefined && data.motherLastName !== '' ? data.motherLastName : (motherParts.length > 1 ? motherParts[motherParts.length - 1] : '');
  const motherMiddleNameVal = data.motherMiddleName !== undefined && data.motherMiddleName !== '' ? data.motherMiddleName : (motherParts.length > 2 ? motherParts.slice(1, -1).join(' ') : '');

  // 2. Date of Birth / Incorporation robust parser
  const targetDob = data.dateOfIncorporation || data.dob;
  let dobDay = '';
  let dobMonth = '';
  let dobYear = '';
  if (targetDob) {
    const str = String(targetDob).trim();
    if (str.includes('-')) {
      const parts = str.split('-');
      if (parts[0].length === 4) {
        dobYear = parts[0];
        dobMonth = parts[1];
        dobDay = parts[2];
      } else {
        dobDay = parts[0];
        dobMonth = parts[1];
        dobYear = parts[2];
      }
    } else if (str.includes('/')) {
      const parts = str.split('/');
      if (parts[0].length === 4) {
        dobYear = parts[0];
        dobMonth = parts[1];
        dobDay = parts[2];
      } else {
        dobDay = parts[0];
        dobMonth = parts[1];
        dobYear = parts[2];
      }
    }
  }

  // 3. Addresses
  const residence = data.residenceAddress || data.address || {
    flatNo: data.flatNo || data.residenceFlatNo || '',
    premises: data.premises || data.residencePremises || '',
    roadStreet: data.roadStreet || data.residenceRoadStreet || '',
    areaTaluka: data.areaTaluka || data.residenceAreaTaluka || '',
    district: data.district || data.residenceDistrict || '',
    state: data.state || data.residenceState || '',
    pincode: data.pincode || data.residencePincode || '',
  };

  const hasOfficeAddressData = !!(
    data.officeAddress ||
    data.officeFlatNo ||
    data.officeRoadStreet ||
    data.officePremises ||
    data.officeAreaTaluka ||
    data.officeDistrict ||
    data.officeState ||
    data.officePincode ||
    data.commFlatNo ||
    data.commRoadStreet ||
    data.commPremises ||
    data.commAreaTaluka ||
    data.commDistrict ||
    data.commState ||
    data.commPincode ||
    data.officeName
  );

  const office = data.officeAddress
    ? data.officeAddress
    : (hasOfficeAddressData ? {
        nameOfOffice: data.officeName || data.nameOfOffice || '',
        flatNo: data.officeFlatNo || data.commFlatNo || '',
        premises: data.officePremises || data.commPremises || '',
        roadStreet: data.officeRoadStreet || data.commRoadStreet || '',
        areaTaluka: data.officeAreaTaluka || data.commAreaTaluka || '',
        district: data.officeDistrict || data.commDistrict || '',
        state: data.officeState || data.commState || '',
        pincode: data.officePincode || data.commPincode || '',
      } : {});

  // 7. Applicant Status
  const statusStr = String(data.category || data.applicantStatus || 'INDIVIDUAL').toUpperCase();

  // 8. Other Name
  const hasOtherName = (data.otherName || '').toUpperCase() === 'YES';

  // 9. Gender
  const genderStr = (data.gender || 'MALE').toUpperCase();

  // 10. Title
  const titleStr = (data.title || 'SHRI').toUpperCase();

  // Age calculation for Minor detection (< 18 years)
  const calculateAgeInPdf = (dobStr) => {
    if (!dobStr || typeof dobStr !== 'string') return 99;
    const trimmed = dobStr.trim();
    if (!trimmed) return 99;
    let year = 0, month = 0, day = 0;
    if (trimmed.includes('-')) {
      const p = trimmed.split('-');
      if (p[0].length === 4) { year = +p[0]; month = +p[1]; day = +p[2]; }
      else { day = +p[0]; month = +p[1]; year = +p[2]; }
    } else if (trimmed.includes('/')) {
      const p = trimmed.split('/');
      if (p[0].length === 4) { year = +p[0]; month = +p[1]; day = +p[2]; }
      else { day = +p[0]; month = +p[1]; year = +p[2]; }
    } else {
      const b = new Date(trimmed);
      if (isNaN(b.getTime())) return 99;
      year = b.getFullYear(); month = b.getMonth() + 1; day = b.getDate();
    }
    if (!year || !month || !day || isNaN(year) || isNaN(month) || isNaN(day)) return 99;
    const bDate = new Date(year, month - 1, day);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    let age = today.getFullYear() - bDate.getFullYear();
    const m = today.getMonth() - bDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < bDate.getDate())) age--;
    return age;
  };
  const pdfAge = calculateAgeInPdf(data.dob || data.dateOfIncorporation);
  const isApplicantMinor = data.isMinor === true || (pdfAge >= 0 && pdfAge < 18);

  // Representative Assessee values (defaults to Guardian fields or father's name if applicant is minor)
  const raFirstNameVal = data.raFirstName || data.guardianFirstName || (isApplicantMinor ? fatherFirstNameVal : '');
  const raMiddleNameVal = data.raMiddleName || data.guardianMiddleName || (isApplicantMinor ? fatherMiddleNameVal : '');
  const raLastNameVal = data.raLastName || data.guardianLastName || (isApplicantMinor ? fatherLastNameVal : '');
  const raPanVal = data.raPan || data.raPanNumber || data.guardianPan || '';
  const raAadhaarVal = data.raAadhaarNumber || data.guardianAadhaarNumber || data.guardianAadhaar || '';
  const raAddressVal = data.representativeAddress || data.raAddress || (isApplicantMinor ? residence : {});
  const raPhotoDisplay = data.raPhotoUrl || data.proofOfOtherUrl || data.thirdPhotoUrl;

  return (
    <div
      id="form93-pdf-container"
      style={{
        display: 'none',
        position: 'absolute',
        left: '-99999px',
        top: '-99999px',
      }}
    >
      {/* ================================================================
          PAGE 1
          ================================================================ */}
      <Page id="form93-pdf-container-page1">
        <div style={{ height: '48mm', position: 'relative' }}>
          <div style={{ position: 'absolute', left: '2mm', top: '1mm' }}>
            <PhotoBox photoUrl={data.photoUrl} signatureUrl={data.signatureUrl} left />
          </div>

          <div
            style={{
              position: 'absolute',
              left: '41mm',
              right: '41mm',
              top: '1mm',
              height: '45mm',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
              alignItems: 'center',
              textAlign: 'center',
              fontWeight: 'bold',
            }}
          >
            <div style={{ fontSize: '11.5pt', fontWeight: 'bold', marginBottom: '1mm' }}>
              {(data.category === 'INDIVIDUAL' || !data.category) ? 'FORM NO. 93' : 'FORM NO. 94'}
            </div>
            <div style={{ fontSize: '8.5pt', fontWeight: 'bold', marginBottom: '1.5mm' }}>
              {(data.category === 'INDIVIDUAL' || !data.category) ? '[See rule 158]' : '[See rule 114]'}
            </div>
            <div style={{ fontSize: '9pt', fontWeight: 'bold', marginBottom: '1mm', lineHeight: 1.2 }}>
              Application for Allotment of Permanent Account Number
            </div>
            <div style={{ fontSize: '7.8pt', fontWeight: 'bold', lineHeight: 1.2, color: '#111' }}>
              [{(data.category === 'INDIVIDUAL' || !data.category) ? 'For an Individual being a Citizen of India' : 'For Entities other than Individuals'}]
            </div>
          </div>

          <div style={{ position: 'absolute', right: '2mm', top: '1mm' }}>
            <PhotoBox photoUrl={data.photoUrl} />
          </div>
        </div>

        <SectionTitle>
          <span style={{ position: 'absolute', left: '10mm' }}>Sr. No.</span>
          PART A - Personal Information
        </SectionTitle>

        {/* 1 */}
        <GreyBar style={{ marginTop: '1mm', height: '5.8mm' }}>
          1. A. Name
        </GreyBar>

        {/* Title row */}
        <div
          style={{
            minHeight: '5.2mm',
            display: 'flex',
            alignItems: 'center',
            padding: '0 2mm',
            gap: '4mm',
            border: '0.28mm solid #777',
            borderBottom: 'none',
            fontSize: '7pt',
            background: '#fafafa'
          }}
        >
          <strong style={{ width: '40mm' }}>Title <i>(select one)</i></strong>
          <Check checked={titleStr === 'SHRI'} label="Shri" />
          <Check checked={titleStr === 'SMT'} label="Smt." />
          <Check checked={titleStr === 'KUMARI'} label="Kumari" />
          <Check checked={titleStr === 'M/S'} label="M/s" />
        </div>

        <div>
          <NameRows
            firstName={fName}
            middleName={mName}
            lastName={lName}
          />
        </div>        <div
          style={{
            background: '#e7e7e7',
            padding: '0.8mm 2mm',
            fontWeight: 'bold',
            fontSize: '7pt',
            marginTop: '0.6mm',
            marginBottom: '0.8mm',
          }}
        >
          B. Name (as per Aadhaar)
        </div>

        <CellRow
          label=""
          value={aadhaarName.slice(0, 30)}
          length={30}
          labelWidth={53}
          boxWidth={4.55}
        />
        <CellRow
          label=""
          value={aadhaarName.slice(30, 60)}
          length={30}
          labelWidth={53}
          boxWidth={4.55}
        />
        <CellRow
          label=""
          value={aadhaarName.slice(60, 90)}
          length={30}
          labelWidth={53}
          boxWidth={4.55}
        />

        {/* 2 Gender */}
        <FullWidthLine style={{ marginTop: '0.6mm' }}>
          <div
            style={{
              minHeight: '5.8mm',
              display: 'flex',
              alignItems: 'center',
              padding: '0 2mm',
              gap: '4mm',
            }}
          >
            <strong style={{ width: '45mm' }}>2. Gender:</strong>
            <Check checked={genderStr === 'MALE'} label="Male" />
            <Check checked={genderStr === 'FEMALE'} label="Female" />
            <Check checked={genderStr === 'TRANSGENDER'} label="Transgender" />
          </div>
        </FullWidthLine>

        {/* 3 DOB */}
        <FullWidthLine>
          <div
            style={{
              minHeight: '5.8mm',
              display: 'flex',
              alignItems: 'center',
              padding: '0 2mm',
            }}
          >
            <strong style={{ width: '45mm' }}>3. Date of Birth</strong>
            <div style={{ display: 'flex', alignItems: 'center', gap: '2mm' }}>
              <BoxGrid value={dobDay ? String(dobDay).padStart(2, '0') : 'dd'} length={2} width={4.55} height={5.05} uppercase={false} />
              <BoxGrid value={dobMonth ? String(dobMonth).padStart(2, '0') : 'mm'} length={2} width={4.55} height={5.05} uppercase={false} />
              <BoxGrid value={dobYear ? String(dobYear).padStart(4, '0') : 'yyyy'} length={4} width={4.55} height={5.05} uppercase={false} />
            </div>
          </div>
        </FullWidthLine>

        {/* 4 Aadhaar */}
        <FullWidthLine>
          <div
            style={{
              minHeight: '5.8mm',
              display: 'flex',
              alignItems: 'center',
              padding: '0 2mm',
            }}
          >
            <strong style={{ width: '45mm' }}>4. Aadhaar Number</strong>
            <BoxGrid value={String(data.aadhaarNumber || '').replace(/\s+/g, '')} length={12} width={4.55} height={5.05} />
          </div>
        </FullWidthLine>



        {/* 5 Residence */}
        <GreyBar style={{ marginTop: '0.6mm' }}>5. Residence Address</GreyBar>
        <div style={{ paddingTop: '0.8mm' }}>
          <AddressRows address={residence} />
        </div>

        {/* 6 Office Address */}
        <GreyBar style={{ marginTop: '0.8mm' }}>6. Office Address</GreyBar>
        <div style={{ paddingTop: '1mm' }}>
          <AddressRows address={office} />
        </div>

        {/* 7 */}
        <FullWidthLine style={{ marginTop: '0.7mm' }}>
          <div
            style={{
              minHeight: '6mm',
              display: 'flex',
              alignItems: 'center',
              padding: '0 2mm',
              gap: '4mm',
            }}
          >
            <strong style={{ width: '48mm' }}>
              7. Residential Status <i>(select one as applicable)</i>
            </strong>
            <Check checked={data.residentialStatus === 'RESIDENT'} label="Resident" />
            <Check checked={data.residentialStatus === 'NON_RESIDENT'} label="Non Resident" />
            <Check
              checked={data.residentialStatus === 'RNOR'}
              label="Resident but Not ordinarily Resident"
            />
          </div>
        </FullWidthLine>

        {/* 8 */}
        <FullWidthLine>
          <div
            style={{
              minHeight: '6mm',
              display: 'flex',
              alignItems: 'center',
              padding: '0 2mm',
            }}
          >
            <strong style={{ width: '85mm' }}>
              8. Passport Number <i>(mandatory for (i) Non Resident (ii) Resident but not ordinarily resident)</i>
            </strong>
            <BoxGrid value={data.passportNumber} length={15} width={4.55} height={5.05} />
          </div>
        </FullWidthLine>

        {/* 9 */}
        <FullWidthLine>
          <div
            style={{
              minHeight: '6mm',
              display: 'flex',
              alignItems: 'center',
              padding: '0 2mm',
            }}
          >
            <strong style={{ width: '78mm' }}>
              9. Taxpayer Identification Number <i>(TIN) in the Country of Residence (if any)</i>
            </strong>
            <BoxGrid value={data.tin} length={20} width={4.55} height={5.05} />
          </div>
        </FullWidthLine>

        {/* 10 */}
        <GreyBar style={{ marginTop: '0.8mm' }}>10. Contact Details</GreyBar>
        <div style={{ padding: '1mm 2mm 0' }}>
          <div style={{ display: 'flex', alignItems: 'center', marginBottom: '1mm' }}>
            <span style={{ width: '56mm' }}>(i) Mobile Number</span>
            <span style={{ marginRight: '2mm' }}>Country Code</span>
            <BoxGrid value={data.countryCode || '91'} length={2} width={4.55} height={5.05} />
            <span style={{ margin: '0 3mm' }}>Mobile Number</span>
            <BoxGrid value={data.mobileNumber} length={10} width={4.55} height={5.05} />
          </div>

          <div style={{ display: 'flex', alignItems: 'center', marginBottom: '1mm' }}>
            <span style={{ width: '56mm' }}>(ii) Email ID</span>
            <div
              style={{
                border: '0.28mm solid #777',
                height: '5.05mm',
                width: '127mm',
                boxSizing: 'border-box',
                padding: '0.7mm 1.5mm',
                fontFamily: 'Arial, sans-serif',
                fontSize: '7pt',
                fontWeight: 'bold',
              }}
            >
              {data.email || ''}
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center' }}>
            <span style={{ width: '56mm', whiteSpace: 'nowrap' }}>(iii) Landline No. with STD Code <i>(if any)</i></span>
            <span style={{ marginRight: '2mm' }}>STD Code</span>
            <BoxGrid value={data.stdCode} length={5} width={4.55} height={5.05} />
            <span style={{ margin: '0 3mm' }}>Landline Number</span>
            <BoxGrid value={data.landlineNumber} length={10} width={4.55} height={5.05} />
          </div>
        </div>

        {/* Part B */}
        <SectionTitle style={{ marginTop: '1.2mm' }}>PART B - Source of Income</SectionTitle>
        <div
          style={{
            border: '0.3mm solid #777',
            borderTop: 'none',
            padding: '1.5mm 2mm',
            boxSizing: 'border-box',
            minHeight: '14mm',
          }}
        >
          <div style={{ fontWeight: 'bold', marginBottom: '1.5mm' }}>
            11. Source of Income <i>(select one or more)</i>
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', columnGap: '12mm', rowGap: '2mm' }}>
            <Check checked={data.incomeSources?.includes?.('SALARY')} label="Salary" />
            <Check checked={data.incomeSources?.includes?.('BUSINESS')} label="Income from Business/Profession" />
            <Check checked={data.incomeSources?.includes?.('HOUSE_PROPERTY')} label="Income from House Property" />
            <Check checked={data.incomeSources?.includes?.('CAPITAL_GAINS')} label="Capital Gains" />
            <Check checked={data.incomeSources?.includes?.('OTHER')} label="Income from Other Sources" />
            <Check checked={data.incomeSources?.includes?.('NONE')} label="No Income" />
          </div>
        </div>
      </Page>

      {/* ================================================================
          PAGE 2
          ================================================================ */}
      <Page id="form93-pdf-container-page2">
        {/* Part C */}
        <SectionTitle style={{ marginTop: '0.5mm' }}>PART C - Details of Parents</SectionTitle>
        <div style={{ border: '0.3mm solid #777', borderTop: 'none' }}>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              minHeight: '6mm',
              padding: '0 2mm',
              gap: '5mm',
            }}
          >
            <strong style={{ width: '88mm' }}>
              12. Whether mother/father is a single parent? <i>(select one)</i>
            </strong>
            <Check checked={data.isSingleParent === 'YES' || data.isSingleParent === 'Yes'} label="Yes" />
            <Check checked={data.isSingleParent === 'NO' || data.isSingleParent === 'No' || !data.isSingleParent} label="No" />
          </div>

          <CellRow label={<strong style={{ fontWeight: 'bold' }}>13. Father's First Name</strong>} value={fatherFirstNameVal} length={25} />
          <CellRow label="Father's Middle Name" value={fatherMiddleNameVal} length={25} />
          <CellRow label="Father's Last Name" value={fatherLastNameVal} length={25} />
          <CellRow label={<strong style={{ fontWeight: 'bold' }}>14. Mother's First Name</strong>} value={motherFirstNameVal} length={25} />
          <CellRow label="Mother's Middle Name" value={motherMiddleNameVal} length={25} />
          <CellRow label="Mother's Last Name" value={motherLastNameVal} length={25} />

          <FullWidthLine style={{ marginTop: '0.8mm' }}>
            <div
              style={{
                minHeight: '7mm',
                display: 'flex',
                alignItems: 'center',
                padding: '0 2mm',
                gap: '5mm',
              }}
            >
              <strong style={{ width: '100mm' }}>
                15. Name of parent to be printed on Permanent Account Number card <i>(select one)</i>
              </strong>
              <Check checked={data.parentNameToPrint === 'FATHER' || data.parentNameToPrint === 'Father'} label="Father" />
              <Check checked={data.parentNameToPrint === 'MOTHER' || data.parentNameToPrint === 'Mother'} label="Mother" />
            </div>
          </FullWidthLine>
        </div>

        {/* Part D */}
        <SectionTitle style={{ marginTop: '0.8mm' }}>
          PART D - Assessing Officer (AO Code)
        </SectionTitle>

        <div
          style={{
            border: '0.3mm solid #777',
            borderTop: 'none',
            minHeight: '19mm',
            display: 'flex',
            boxSizing: 'border-box',
          }}
        >
          <div
            style={{
              width: '55mm',
              background: '#e7e7e7',
              padding: '2mm',
              boxSizing: 'border-box',
              fontWeight: 'bold',
            }}
          >
            16. Assessing Officer
            <br />
            (AO Code)
          </div>

          <div
            style={{
              flex: 1,
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              padding: '2mm 4mm',
              rowGap: '2.5mm',
              columnGap: '8mm',
              boxSizing: 'border-box',
            }}
          >
            {[
              ['(i) Area Code', data.aoAreaCode, 3],
              ['(ii) AO Type', data.aoType, 2],
              ['(iii) Range Code', data.aoRangeCode, 3],
              ['(iv) AO No.', data.aoNo, 2],
            ].map(([label, value, len]) => (
              <div key={label} style={{ display: 'flex', alignItems: 'center', gap: '2mm' }}>
                <span style={{ width: '28mm' }}>{label}</span>
                <BoxGrid value={value} length={len} width={5} height={5.2} />
              </div>
            ))}
          </div>
        </div>

        {/* Part E */}
        <SectionTitle style={{ marginTop: '0.8mm' }}>
          PART E - Representative Assessee, if applicable {isApplicantMinor ? '(Mandatory for Minor Applicant < 18 Years)' : ''}
        </SectionTitle>

        <div style={{ border: '0.3mm solid #777', borderTop: 'none', position: 'relative' }}>
          {/* Display 3rd Uploaded Photo (Representative Assessee / Guardian Photo) */}
          {raPhotoDisplay && (
            <div style={{ position: 'absolute', right: '3mm', top: '2mm', zIndex: 10, textAlign: 'center' }}>
              <div style={{ width: '26mm', height: '33mm', border: '0.35mm solid #444', background: '#fff', overflow: 'hidden', boxShadow: '0 1mm 2mm rgba(0,0,0,0.15)' }}>
                <img
                  src={raPhotoDisplay}
                  alt="3rd Photo (RA)"
                  style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                />
              </div>
              <span style={{ fontSize: '5.5pt', fontWeight: 'bold', display: 'block', marginTop: '0.5mm', color: '#111' }}>
                3rd Photo (RA / Guardian)
              </span>
            </div>
          )}

          <CellRow label={<strong style={{ fontWeight: 'bold' }}>17. RA's First Name</strong>} value={raFirstNameVal} length={raPhotoDisplay ? 19 : 25} />
          <CellRow label="RA's Middle Name" value={raMiddleNameVal} length={raPhotoDisplay ? 19 : 25} />
          <CellRow label="RA's Last Name" value={raLastNameVal} length={raPhotoDisplay ? 19 : 25} />

          <FullWidthLine>
            <div
              style={{
                minHeight: '6mm',
                display: 'flex',
                alignItems: 'center',
                padding: '0 2mm',
              }}
            >
              <strong style={{ width: '78mm' }}>18. Permanent Account Number (if any)</strong>
              <BoxGrid value={raPanVal} length={10} width={5.45} height={5.05} />
            </div>
          </FullWidthLine>

          <FullWidthLine>
            <div
              style={{
                minHeight: '6mm',
                display: 'flex',
                alignItems: 'center',
                padding: '0 2mm',
              }}
            >
              <strong style={{ width: '78mm' }}>
                19. Aadhaar Number <i>(if Permanent Account Number is not available)</i>
              </strong>
              <BoxGrid value={raAadhaarVal} length={12} width={5.45} height={5.05} />
            </div>
          </FullWidthLine>

          <GreyBar style={{ marginTop: '0.5mm' }}>20. Representative Assessee Address</GreyBar>
          <div style={{ paddingTop: '1mm' }}>
            <AddressRows address={raAddressVal} />
          </div>

          <GreyBar style={{ marginTop: '0.7mm' }}>21. Contact Details</GreyBar>
          <div style={{ padding: '1mm 2mm' }}>
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: '1mm' }}>
              <span style={{ width: '56mm' }}>(i) Mobile Number</span>
              <span style={{ marginRight: '2mm' }}>Country Code</span>
              <BoxGrid value={data.raCountryCode || '91'} length={2} width={4.55} height={5.05} />
              <span style={{ margin: '0 3mm' }}>Mobile Number</span>
              <BoxGrid value={data.raMobileNumber} length={10} width={4.55} height={5.05} />
            </div>

            <div style={{ display: 'flex', alignItems: 'center', marginBottom: '1mm' }}>
              <span style={{ width: '56mm' }}>(ii) Email ID</span>
              <div
                style={{
                  border: '0.28mm solid #777',
                  height: '5.05mm',
                  width: '127mm',
                  boxSizing: 'border-box',
                  padding: '0.7mm 1.5mm',
                  fontSize: '7pt',
                  fontWeight: 'bold',
                }}
              >
                {data.raEmail || ''}
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center' }}>
              <span style={{ width: '56mm', whiteSpace: 'nowrap' }}>(iii) Landline No. with STD Code <i>(if any)</i></span>
              <span style={{ marginRight: '2mm' }}>STD Code</span>
              <BoxGrid value={data.raStdCode} length={5} width={4.55} height={5.05} />
              <span style={{ margin: '0 3mm' }}>Landline Number</span>
              <BoxGrid value={data.raLandlineNumber} length={10} width={4.55} height={5.05} />
            </div>
          </div>
        </div>

        {/* Part F */}
        <SectionTitle style={{ marginTop: '0.8mm' }}>
          Part F: Communication Address
        </SectionTitle>

        <div
          style={{
            border: '0.3mm solid #777',
            borderTop: 'none',
            minHeight: '8mm',
            display: 'flex',
            alignItems: 'center',
            padding: '0 2mm',
            gap: '7mm',
            boxSizing: 'border-box',
          }}
        >
          <strong style={{ width: '50mm' }}>
            22. Address for Communication <i>(select one)</i>
          </strong>
          <Check checked={data.communicationAddress === 'RESIDENCE'} label="Residence Address" />
          <Check checked={data.communicationAddress === 'RA'} label="Representative Assessee Address" />
          <Check checked={data.communicationAddress === 'OFFICE'} label="Office Address" />
        </div>

        {/* Part G */}
        <SectionTitle style={{ marginTop: '0.8mm' }}>
          Part G: Declaration by Applicant or by Representative Assessee on behalf of the Applicant
        </SectionTitle>

        <div style={{ border: '0.3mm solid #777', borderTop: 'none' }}>
          <div
            style={{
              padding: '1.5mm 2mm',
              fontWeight: 'bold',
              fontSize: '7.3pt',
            }}
          >
            23. Documents submitted as Proof of Identity, Proof of Address and Proof of Date of Birth of the Applicant
          </div>

          <div
            style={{
              padding: '1mm 8mm 1.5mm',
              display: 'flex',
              gap: '13mm',
            }}
          >
            <Check checked={data.proofOfIdentity} label="(i) Proof of Identity" />
            <Check checked={data.proofOfAddress} label="(ii) Proof of Address" />
            <Check checked={data.proofOfDob} label="(iii) Proof of Date of Birth" />
          </div>

          <div
            style={{
              borderTop: '0.25mm solid #aaa',
              padding: '1.5mm 2mm',
              fontWeight: 'bold',
              fontSize: '7.3pt',
            }}
          >
            24. Documents submitted as Proof of Identity, Proof of Address of Representative Assessee
          </div>

          <div
            style={{
              padding: '1mm 8mm 1.5mm',
              display: 'flex',
              gap: '13mm',
            }}
          >
            <Check checked={data.raProofOfIdentity} label="(i) Proof of Identity" />
            <Check checked={data.raProofOfAddress} label="(ii) Proof of Address" />
          </div>

          <div
            style={{
              borderTop: '0.3mm solid #555',
              textAlign: 'center',
              fontWeight: 'bold',
              padding: '1mm',
              fontSize: '8.2pt',
            }}
          >
            Verification & Declaration
          </div>

          <div
            style={{
              padding: '2mm 3mm 2mm',
              fontSize: '7.4pt',
              lineHeight: 1.35,
            }}
          >
            <div>
              a. I,{' '}
              <span style={{ textDecoration: 'underline', fontWeight: 'bold' }}>
                {data.verifierName || fullName.toUpperCase()}
              </span>
              , in the capacity of{' '}
              <span style={{ textDecoration: 'underline' }}>
                {data.verifierCapacity || data.representativeCapacity || 'Self'}
              </span>{' '}
              (Self/ Representative Assessee) do hereby declare that what is stated above is true to the best of my knowledge and belief.
            </div>

            <div style={{ marginTop: '1.2mm' }}>
              b. I declare that the applicant does not possess Permanent Account Number and shall be liable for legal consequences under Income-Tax Act, 2025 if this declaration is found to be incorrect
            </div>

            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'flex-start',
                marginTop: '3mm',
              }}
            >
              <div style={{ width: '65mm', paddingTop: '2mm' }}>
                <div style={{ marginBottom: '4mm', fontSize: '7.5pt' }}>
                  Place: {data.verifierPlace || data.place || '................'}
                </div>
                <div style={{ fontSize: '7.5pt' }}>
                  Date: {data.verifierDate || data.date || '...............'}
                </div>
              </div>

              <div
                style={{
                  width: '85mm',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  textAlign: 'center',
                }}
              >
                <div
                  style={{
                    width: '78mm',
                    height: '25mm',
                    border: '0.3mm solid #555',
                    boxSizing: 'border-box',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    overflow: 'hidden',
                    background: '#fff',
                  }}
                >
                  {data.signatureUrl ? (
                    <img
                      src={data.signatureUrl}
                      alt="Signature"
                      style={{
                        maxWidth: '74mm',
                        maxHeight: '22mm',
                        objectFit: 'contain',
                      }}
                    />
                  ) : (
                    <span style={{ fontSize: '6.8pt', color: '#666' }}>
                      Signature / Left Hand Thumb Impression
                    </span>
                  )}
                </div>

                <div
                  style={{
                    fontSize: '6.8pt',
                    marginTop: '1mm',
                    lineHeight: 1.15,
                    width: '78mm',
                    textAlign: 'center',
                  }}
                >
                  (Signature / Left Hand Thumb Impression of Applicant or Representative Assessee)
                </div>

                <div
                  style={{
                    width: '78mm',
                    marginTop: '2.5mm',
                    textAlign: 'left',
                    fontSize: '7.3pt',
                  }}
                >
                  <div>Name: {(data.verifierName || fullName.toUpperCase() || '').trim() || '____________________________'}</div>
                  <div style={{ marginTop: '1.8mm' }}>
                    Designation: {(data.verifierCapacity || data.representativeCapacity || '').trim() || '________________________'}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Page>
    </div>
  );
};

/* ============================================================================
   FORM NO. 94 - Non-Individual Categories
   (Company, HUF, Firm, Trust, BOI, AOP, Local Authority, AJP, Government, LLP)
   ============================================================================ */
const Form94PdfTemplate = ({ data = {} }) => {
  const entityTitleName = (data.entityName || data.applicantName || data.lastName || data.nameAsPerAadhaar || '').toUpperCase();

  // Date of Incorporation parsing
  const targetDob = data.dateOfIncorporation || data.dob;
  let dobDay = '';
  let dobMonth = '';
  let dobYear = '';
  if (targetDob) {
    const str = String(targetDob).trim();
    if (str.includes('-')) {
      const parts = str.split('-');
      if (parts[0].length === 4) {
        dobYear = parts[0];
        dobMonth = parts[1];
        dobDay = parts[2];
      } else {
        dobDay = parts[0];
        dobMonth = parts[1];
        dobYear = parts[2];
      }
    } else if (str.includes('/')) {
      const parts = str.split('/');
      if (parts[0].length === 4) {
        dobYear = parts[0];
        dobMonth = parts[1];
        dobDay = parts[2];
      } else {
        dobDay = parts[0];
        dobMonth = parts[1];
        dobYear = parts[2];
      }
    }
  }

  // Addresses
  const office = data.officeAddress || data || {};
  const comm = data.residenceAddress || data.address || data || {};

  // Category / Status string
  const statusStr = String(data.category || data.applicantStatus || 'COMPANY').toUpperCase();

  // Representative Assessee / Authorized Representative (RA / AR)
  const raFirstNameVal = data.raFirstName || '';
  const raMiddleNameVal = data.raMiddleName || '';
  const raLastNameVal = data.raLastName || '';
  const raFullName = `${raFirstNameVal} ${raMiddleNameVal} ${raLastNameVal}`.replace(/\s+/g, ' ').trim() || (data.verifierName || entityTitleName);

  return (
    <div
      id="form93-pdf-container"
      style={{
        display: 'none',
        position: 'absolute',
        left: '-99999px',
        top: '-99999px',
      }}
    >
      {/* ================================================================
          PAGE 1 (FORM NO. 94)
          ================================================================ */}
      <Page id="form93-pdf-container-page1">
        <div style={{ textAlign: 'center', paddingTop: '1mm', paddingBottom: '2mm' }}>
          <div style={{ fontSize: '11pt', fontWeight: 'bold', marginBottom: '0.5mm' }}>
            FORM NO. 94
          </div>
          <div style={{ fontSize: '7.5pt', fontWeight: 'bold' }}>[See rule 158]</div>
          <div style={{ fontSize: '8.5pt', fontWeight: 'bold', marginTop: '1mm', lineHeight: 1.2 }}>
            Application for Allotment of Permanent Account Number
          </div>
          <div style={{ fontSize: '7.2pt', fontWeight: 'bold', marginTop: '0.5mm', lineHeight: 1.2, color: '#111' }}>
            (For an Indian Company / an Entity incorporated in India / an Unincorporated Entity formed in India)
          </div>
        </div>

        <SectionTitle>
          <span style={{ position: 'absolute', left: '10mm' }}>Sr. No.</span>
          Part A - Personal Information
        </SectionTitle>

        {/* 1. Name */}
        <GreyBar style={{ marginTop: '1mm', height: '5.8mm' }}>
          1. Name
        </GreyBar>
        <div style={{ padding: '1mm 0' }}>
          <CellRow label="" value={entityTitleName.slice(0, 30)} length={30} labelWidth={53} boxWidth={4.55} />
          <CellRow label="" value={entityTitleName.slice(30, 60)} length={30} labelWidth={53} boxWidth={4.55} />
          <CellRow label="" value={entityTitleName.slice(60, 90)} length={30} labelWidth={53} boxWidth={4.55} />
        </div>

        {/* 2. Date of Incorporation */}
        <FullWidthLine style={{ marginTop: '0.6mm' }}>
          <div
            style={{
              minHeight: '6.5mm',
              display: 'flex',
              alignItems: 'center',
              padding: '0 2mm',
              fontSize: '6.8pt',
            }}
          >
            <strong style={{ width: '105mm', lineHeight: 1.15 }}>
              2. Date of Incorporation/Agreement/Partnership or Trust Deed/Formation of Body of Individuals or Association of Persons
            </strong>
            <span style={{ margin: '0 2mm' }}>D D</span>
            <BoxGrid value={dobDay} length={2} width={4.55} height={5.05} />
            <span style={{ margin: '0 2mm' }}>M M</span>
            <BoxGrid value={dobMonth} length={2} width={4.55} height={5.05} />
            <span style={{ margin: '0 2mm' }}>Y Y Y Y</span>
            <BoxGrid value={dobYear} length={4} width={4.55} height={5.05} />
          </div>
        </FullWidthLine>

        {/* 3. Office Address */}
        <GreyBar style={{ marginTop: '0.6mm' }}>3. Office Address</GreyBar>
        <div style={{ paddingTop: '0.8mm' }}>
          <AddressRows address={office} />
        </div>

        {/* 4. Communication Address */}
        <GreyBar style={{ marginTop: '0.8mm' }}>4. Communication Address</GreyBar>
        <div style={{ paddingTop: '0.8mm' }}>
          <AddressRows address={comm} />
        </div>

        {/* 5. Status */}
        <FullWidthLine style={{ marginTop: '0.6mm' }}>
          <div style={{ padding: '1.2mm 2mm', fontSize: '6.8pt' }}>
            <strong style={{ display: 'block', marginBottom: '1.2mm' }}>
              5. Status <i>(select one as applicable)</i>:
            </strong>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', rowGap: '1.8mm', columnGap: '2mm' }}>
              <Check checked={statusStr === 'HUF' || statusStr.includes('HINDU')} label="Hindu Undivided Family" />
              <Check checked={statusStr === 'COMPANY'} label="Company" />
              <Check checked={statusStr === 'FIRM'} label="Firm" />
              <Check checked={statusStr === 'AOP' || statusStr.includes('ASSOCIATION')} label="Association of Persons" />
              <Check checked={statusStr === 'BOI' || statusStr.includes('BODY')} label="Body of Individuals" />
              <Check checked={statusStr === 'LOCAL_AUTHORITY' || statusStr.includes('LOCAL')} label="Local Authority" />
              <Check checked={statusStr === 'AJP' || statusStr.includes('ARTIFICIAL') || statusStr.includes('JUDICIAL') || statusStr.includes('JURIDICAL')} label="Artificial Juridical Person" />
              <Check checked={statusStr === 'GOVERNMENT'} label="Government" />
              <Check checked={statusStr === 'TRUST'} label="Trust" />
              <Check checked={statusStr === 'LLP' || statusStr.includes('LIMITED')} label="Limited Liability Partnership" />
            </div>
          </div>
        </FullWidthLine>

        {/* 6. Registration Number */}
        <FullWidthLine>
          <div
            style={{
              minHeight: '6.5mm',
              display: 'flex',
              alignItems: 'center',
              padding: '0 2mm',
              fontSize: '6.5pt',
            }}
          >
            <strong style={{ width: '105mm', lineHeight: 1.15 }}>
              6. Registration Number <i>(for Company, Firm, LLP, AOP, BOI, AJP and Trust)</i>
            </strong>
            <BoxGrid value={data.registrationNumber || data.cin || data.llpin || ''} length={16} width={4.55} height={5.05} />
          </div>
        </FullWidthLine>

        {/* 7. Contact Details */}
        <GreyBar style={{ marginTop: '0.6mm' }}>7. Contact Details</GreyBar>
        <div style={{ padding: '1mm 2mm 0' }}>
          <div style={{ display: 'flex', alignItems: 'center', marginBottom: '1mm' }}>
            <span style={{ width: '56mm' }}>(i) Mobile Number</span>
            <span style={{ marginRight: '2mm' }}>Country Code</span>
            <BoxGrid value={data.countryCode || '91'} length={2} width={4.55} height={5.05} />
            <span style={{ margin: '0 3mm' }}>Mobile Number</span>
            <BoxGrid value={data.mobileNumber} length={10} width={4.55} height={5.05} />
          </div>

          <div style={{ display: 'flex', alignItems: 'center', marginBottom: '1mm' }}>
            <span style={{ width: '56mm' }}>(ii) Email ID</span>
            <div
              style={{
                border: '0.28mm solid #777',
                height: '5.05mm',
                width: '127mm',
                boxSizing: 'border-box',
                padding: '0.7mm 1.5mm',
                fontFamily: 'Arial, sans-serif',
                fontSize: '7pt',
                fontWeight: 'bold',
              }}
            >
              {data.email || ''}
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center' }}>
            <span style={{ width: '56mm', whiteSpace: 'nowrap' }}>(iii) Landline No. with STD Code <i>(if any)</i></span>
            <span style={{ marginRight: '2mm' }}>STD Code</span>
            <BoxGrid value={data.stdCode} length={5} width={4.55} height={5.05} />
            <span style={{ margin: '0 3mm' }}>Landline Number</span>
            <BoxGrid value={data.landlineNumber} length={10} width={4.55} height={5.05} />
          </div>
        </div>

        {/* PART B */}
        <SectionTitle style={{ marginTop: '1.2mm' }}>PART B - Source of Income</SectionTitle>
        <div
          style={{
            border: '0.3mm solid #777',
            borderTop: 'none',
            padding: '1.5mm 2mm',
            boxSizing: 'border-box',
            minHeight: '12mm',
          }}
        >
          <div style={{ fontWeight: 'bold', marginBottom: '1.2mm' }}>
            8. Source of Income <i>(select one or more)</i>
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', columnGap: '12mm', rowGap: '2mm' }}>
            <Check checked={data.incomeSources?.includes?.('SALARY')} label="Salary" />
            <Check checked={data.incomeSources?.includes?.('BUSINESS')} label="Income from Business/Profession" />
            <Check checked={data.incomeSources?.includes?.('HOUSE_PROPERTY')} label="Income from House Property" />
            <Check checked={data.incomeSources?.includes?.('CAPITAL_GAINS')} label="Capital Gains" />
            <Check checked={data.incomeSources?.includes?.('OTHER')} label="Income from Other Sources" />
            <Check checked={data.incomeSources?.includes?.('NONE')} label="No Income" />
          </div>
        </div>

        {/* PART C */}
        <SectionTitle style={{ marginTop: '1.2mm' }}>
          PART C - Assessing Officer (AO Code)
        </SectionTitle>
        <div
          style={{
            border: '0.3mm solid #777',
            borderTop: 'none',
            minHeight: '18mm',
            display: 'flex',
            boxSizing: 'border-box',
          }}
        >
          <div
            style={{
              width: '55mm',
              background: '#e7e7e7',
              padding: '2mm',
              boxSizing: 'border-box',
              fontWeight: 'bold',
            }}
          >
            9. Assessing Officer
            <br />
            (AO Code)
          </div>

          <div
            style={{
              flex: 1,
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              padding: '2mm 4mm',
              rowGap: '2.5mm',
              columnGap: '8mm',
              boxSizing: 'border-box',
            }}
          >
            {[
              ['(i) Area Code', data.aoAreaCode, 3],
              ['(ii) AO Type', data.aoType, 2],
              ['(iii) Range Code', data.aoRangeCode, 3],
              ['(iv) AO No.', data.aoNo, 2],
            ].map(([label, value, len]) => (
              <div key={label} style={{ display: 'flex', alignItems: 'center', gap: '2mm' }}>
                <span style={{ width: '28mm' }}>{label}</span>
                <BoxGrid value={value} length={len} width={5} height={5.2} />
              </div>
            ))}
          </div>
        </div>
      </Page>

      {/* ================================================================
          PAGE 2 (FORM NO. 94)
          ================================================================ */}
      <Page id="form93-pdf-container-page2">
        <SectionTitle style={{ marginTop: '0.5mm' }}>
          PART D - Representative Assessee (RA)/Authorized Representative (AR)
        </SectionTitle>
        <div style={{ border: '0.3mm solid #777', borderTop: 'none' }}>
          <CellRow label={<strong style={{ fontWeight: 'bold' }}>10. RA / AR First Name</strong>} value={raFirstNameVal} length={25} />
          <CellRow label="RA / AR Middle Name" value={raMiddleNameVal} length={25} />
          <CellRow label="RA / AR Last Name" value={raLastNameVal} length={25} />

          <FullWidthLine>
            <div
              style={{
                minHeight: '6mm',
                display: 'flex',
                alignItems: 'center',
                padding: '0 2mm',
              }}
            >
              <strong style={{ width: '78mm' }}>11. Permanent Account Number (if any)</strong>
              <BoxGrid value={data.raPan} length={10} width={5.45} height={5.05} />
            </div>
          </FullWidthLine>

          <FullWidthLine>
            <div
              style={{
                minHeight: '6mm',
                display: 'flex',
                alignItems: 'center',
                padding: '0 2mm',
              }}
            >
              <strong style={{ width: '78mm' }}>
                12. Aadhaar Number <i>(if Permanent Account Number is not available)</i>
              </strong>
              <BoxGrid value={data.raAadhaarNumber} length={12} width={5.45} height={5.05} />
            </div>
          </FullWidthLine>

          <GreyBar style={{ marginTop: '0.5mm' }}>13. RA / AR Address</GreyBar>
          <div style={{ paddingTop: '1mm' }}>
            <AddressRows address={data.representativeAddress || data.raAddress || {}} />
          </div>

          <GreyBar style={{ marginTop: '0.7mm' }}>14. Contact Details</GreyBar>
          <div style={{ padding: '1mm 2mm' }}>
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: '1mm' }}>
              <span style={{ width: '56mm' }}>(i) Mobile Number</span>
              <span style={{ marginRight: '2mm' }}>Country Code</span>
              <BoxGrid value={data.raCountryCode || '91'} length={2} width={4.55} height={5.05} />
              <span style={{ margin: '0 3mm' }}>Mobile Number</span>
              <BoxGrid value={data.raMobileNumber} length={10} width={4.55} height={5.05} />
            </div>

            <div style={{ display: 'flex', alignItems: 'center', marginBottom: '1mm' }}>
              <span style={{ width: '56mm' }}>(ii) Email ID</span>
              <div
                style={{
                  border: '0.28mm solid #777',
                  height: '5.05mm',
                  width: '127mm',
                  boxSizing: 'border-box',
                  padding: '0.7mm 1.5mm',
                  fontSize: '7pt',
                  fontWeight: 'bold',
                }}
              >
                {data.raEmail || ''}
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center' }}>
              <span style={{ width: '56mm', whiteSpace: 'nowrap' }}>(iii) Landline No. with STD Code <i>(if any)</i></span>
              <span style={{ marginRight: '2mm' }}>STD Code</span>
              <BoxGrid value={data.raStdCode} length={5} width={4.55} height={5.05} />
              <span style={{ margin: '0 3mm' }}>Landline Number</span>
              <BoxGrid value={data.raLandlineNumber} length={10} width={4.55} height={5.05} />
            </div>
          </div>
        </div>

        {/* PART E */}
        <SectionTitle style={{ marginTop: '1.4mm' }}>
          PART E - Declaration by Applicant or by Representative Assessee/Authorized Representative on behalf of the Applicant
        </SectionTitle>

        <div style={{ border: '0.3mm solid #777', borderTop: 'none' }}>
          <div
            style={{
              padding: '1.8mm 2mm',
              fontWeight: 'bold',
              fontSize: '7.1pt',
            }}
          >
            15. Documents submitted as Proof of Identity, Proof of Address and Proof of Date of Incorporation/Agreement/Partnership or Trust Deed/Formation of Body of Individuals or Association of Persons of the Applicant
          </div>

          <div
            style={{
              padding: '1mm 8mm 2mm',
              display: 'flex',
              gap: '10mm',
              fontSize: '6.8pt'
            }}
          >
            <Check checked={data.proofOfIdentity} label="(i) Proof of Identity" />
            <Check checked={data.proofOfAddress} label="(ii) Proof of Address" />
            <Check checked={data.proofOfDob || data.proofOfIncorporation} label="(iii) Proof of Date of Incorporation/Agreement/Partnership or Trust Deed" />
          </div>

          <div
            style={{
              borderTop: '0.25mm solid #aaa',
              padding: '1.8mm 2mm',
              fontWeight: 'bold',
              fontSize: '7.1pt',
            }}
          >
            16. Documents submitted as Proof of Identity, Proof of Address of Representative Assessee/Authorized Representative
          </div>

          <div
            style={{
              padding: '1mm 8mm 2mm',
              display: 'flex',
              gap: '13mm',
            }}
          >
            <Check checked={data.raProofOfIdentity} label="(i) Proof of Identity" />
            <Check checked={data.raProofOfAddress} label="(ii) Proof of Address" />
          </div>

          <div
            style={{
              borderTop: '0.3mm solid #555',
              textAlign: 'center',
              fontWeight: 'bold',
              padding: '1.2mm',
              fontSize: '8.5pt',
            }}
          >
            Verification & Declaration
          </div>

          <div
            style={{
              padding: '2.5mm 3mm 1mm',
              fontSize: '7.6pt',
              lineHeight: 1.4,
            }}
          >
            <div>
              a. I,{' '}
              <span style={{ textDecoration: 'underline', fontWeight: 'bold' }}>
                {raFullName.toUpperCase()}
              </span>
              , in the capacity of{' '}
              <span style={{ textDecoration: 'underline' }}>
                {data.representativeCapacity || 'Authorized Representative'}
              </span>{' '}
              do hereby declare that what is stated above is true to the best of my knowledge and belief.
            </div>

            <div style={{ marginTop: '1.5mm' }}>
              b. I declare that the applicant does not possess Permanent Account Number and shall be liable for legal consequences under Income-Tax Act, 2025 if this declaration is found to be incorrect.
            </div>

            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                marginTop: '4mm',
              }}
            >
              <div style={{ width: '65mm' }}>
                <div style={{ marginBottom: '3mm' }}>
                  Designation..........
                </div>
                <div style={{ marginBottom: '3mm' }}>
                  Place..........
                </div>
                <div>Date..........</div>
              </div>

              <div
                style={{
                  width: '75mm',
                  height: '32mm',
                  border: '0.3mm solid #555',
                  boxSizing: 'border-box',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  overflow: 'hidden',
                }}
              >
                {data.signatureUrl ? (
                  <img
                    src={data.signatureUrl}
                    alt="Signature"
                    style={{
                      maxWidth: '70mm',
                      maxHeight: '27mm',
                      objectFit: 'contain',
                    }}
                  />
                ) : (
                  <span style={{ fontSize: '7pt' }}>
                    Signature / Left Hand Thumb Impression
                  </span>
                )}
              </div>
            </div>

            <div
              style={{
                textAlign: 'right',
                paddingRight: '10mm',
                marginTop: '0.5mm',
                fontSize: '6.5pt',
              }}
            >
              (Signature / Left Hand Thumb Impression of Applicant or Representative Assessee or Authorized Representative)
            </div>

            <div
              style={{
                width: '75mm',
                marginLeft: 'auto',
                marginTop: '3mm',
                paddingRight: '10mm',
                boxSizing: 'border-box',
                fontSize: '7.5pt',
              }}
            >
              <div>Name: ____________________________</div>
              <div style={{ marginTop: '2.5mm' }}>
                Designation: ________________________
              </div>
            </div>
          </div>
        </div>
      </Page>
    </div>
  );
};

const MainPanPdfTemplate = ({ data = {} }) => {
  const isIndividual = !data.category || data.category === 'INDIVIDUAL';
  if (isIndividual) {
    return <Form93PdfTemplate data={data} />;
  }
  return <Form94PdfTemplate data={data} />;
};

export const generateForm49APdf = generateForm93Pdf;

export default MainPanPdfTemplate;
