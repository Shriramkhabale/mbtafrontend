import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Swal from 'sweetalert2';
import './Dashboard.css';
import logoImg from '../../assets/logo.png';
import WalletModal from '../wallet/WalletModal';
import LedgerView from '../ledger/LedgerView';
import PanCardView from '../pancard/PanCardView';
import QuickLinksView from '../quicklinks/QuickLinksView';
import NotificationBell from '../../context/NotificationBell';
import { API_URL } from '../../utils/apiClient';
import { DYNAMIC_LINK_MENUS, findDynamicMenu, getDynamicMenuForSidebarItem } from '../../utils/dynamicLinkMenus';

// eslint-disable-next-line no-unused-vars
const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 5000,
  timerProgressBar: true
});

const getMenuIcon = (label, url) => {
  if (!label && !url) return null;
  const dyn = (url ? findDynamicMenu(url) : null) || findDynamicMenu(label);
  if (dyn) {
    let colorClass = 'icon-teal';
    if (dyn.key === 'servicesLink') colorClass = 'icon-orange';
    else if (dyn.key === 'jobLinks') colorClass = 'icon-blue';
    else if (dyn.key === 'admitCard') colorClass = 'icon-purple';
    else if (dyn.key === 'formLinks') colorClass = 'icon-teal';
    else if (dyn.key === 'vedioLink') colorClass = 'icon-orange';
    else if (dyn.key === 'trainingLinks') colorClass = 'icon-blue';
    else if (dyn.key === 'productLinks') colorClass = 'icon-amber';
    else if (dyn.key === 'govtLinks') colorClass = 'icon-purple';
    else if (dyn.key === 'print') colorClass = 'icon-slate';
    else if (dyn.key === 'schorshipLinks') colorClass = 'icon-teal';
    return <span className={`icon-badge ${colorClass}`}>{dyn.icon}</span>;
  }
  const l = label.toLowerCase();
  if (l.includes('dash')) return <span className="icon-badge icon-orange">📊</span>;
  if (l.includes('adhar') || l.includes('aadhaar')) return <span className="icon-badge icon-purple">ID</span>;
  if (l.includes('pan')) return <span className="icon-badge icon-amber">💳</span>;
  if (l.includes('report') || l.includes('history')) return <span className="icon-badge icon-blue">📑</span>;
  if (l.includes('link') || l.includes('quick')) return <span className="icon-badge icon-teal">🔗</span>;
  if (l.includes('user') || l.includes('profile')) return <span className="icon-badge icon-teal">👤</span>;
  if (l.includes('setting')) return <span className="icon-badge icon-slate">⚙️</span>;
  return <span className="icon-badge icon-orange">⚡</span>;
};

const getTabIcon = (label) => {
  if (!label) return null;
  const l = label.toLowerCase();
  if (l.includes('wallet point') || (l.includes('wallet') && !l.includes('ledger'))) return <span className="tab-icon">💼</span>;
  if (l.includes('ledger') || l.includes('report')) return <span className="tab-icon">📒</span>;
  if (l.includes('dmt') || l.includes('transfer') || l.includes('money')) return <span className="tab-icon">💸</span>;
  if (l.includes('hotel')) return <span className="tab-icon">🏨</span>;
  if (l.includes('recharge') || l.includes('bill')) return <span className="tab-icon">📱</span>;
  if (l.includes('travel') || l.includes('flight') || l.includes('bus') || l.includes('train')) return <span className="tab-icon">✈️</span>;
  if (l.includes('aeps') || l.includes('withdraw')) return <span className="tab-icon">🏧</span>;
  if (l.includes('insurance')) return <span className="tab-icon">🛡️</span>;
  return <span className="tab-icon">🚀</span>;
};

const Dashboard = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const isLedgerRoute = location.pathname === '/ledger';
  const isWalletRoute = location.pathname === '/wallet';
  const isPanCardRoute = location.pathname === '/pancard' || location.pathname === '/pan-card';
  const isQuickLinksRoute = location.pathname === '/quick-links' || location.pathname === '/view-links';
  const activeDynLinkMenu = findDynamicMenu(location.pathname);
  const isDynLinkMenuRoute = Boolean(activeDynLinkMenu);
  const isStandaloneRoute = isLedgerRoute || isWalletRoute || isPanCardRoute || isQuickLinksRoute || isDynLinkMenuRoute;

  const [theme, setTheme] = useState(() => {
    return localStorage.getItem('appTheme') || 'light';
  });

  const [actionCardsData, setActionCardsData] = useState([]);
  const [topTabsData, setTopTabsData] = useState([]);
  const [sidebarMenuData, setSidebarMenuData] = useState([]);
  const [bannersData, setBannersData] = useState([]);
  const [activeMenuId, setActiveMenuId] = useState(null);
  const [activeTabId, setActiveTabId] = useState(null);
  const [activeCardId, setActiveCardId] = useState(null);
  const [activeBannerId, setActiveBannerId] = useState(null);

  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showWallet, setShowWallet] = useState(false);
  const [walletTab, setWalletTab] = useState('directPayment');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Sync /wallet URL route with showWallet modal state
  useEffect(() => {
    if (location.pathname === '/wallet') {
      setShowWallet(true);
    } else {
      setShowWallet(false);
    }
  }, [location.pathname]);



  const [walletBalance, setWalletBalance] = useState(0);
  const [showBalance, setShowBalance] = useState(() => {
    return localStorage.getItem('showWalletBalance') === 'true';
  });
  const [marqueeText, setMarqueeText] = useState('WELCOME TO MB MITRA');

  useEffect(() => {
    fetch(`${API_URL}/api/site-settings/dashboard_marquee`)
      .then(res => res.json())
      .then(data => {
        if (data && data.success && data.value) {
          setMarqueeText(data.value);
        }
      })
      .catch(() => {});
  }, []);

  const toggleShowBalance = () => {
    setShowBalance(prev => {
      const nextState = !prev;
      localStorage.setItem('showWalletBalance', String(nextState));
      return nextState;
    });
  };



  useEffect(() => {
    // Fetch Action Cards
    fetch(`${API_URL}/api/action-cards`)
      .then(res => res.json())
      .then(data => {
        setActionCardsData(data);
        if (data.length > 0) setActiveCardId(data[0]._id || data[0].id);
      });

    // Fetch Top Tabs
    fetch(`${API_URL}/api/top-tabs`)
      .then(res => res.json())
      .then(data => {
        let tabs = Array.isArray(data) ? [...data] : [];
        if (!tabs.some(t => t.label && t.label.toLowerCase().includes('wallet point'))) {
          tabs.unshift({ _id: 'tab_wallet_points', label: 'Wallet Points' });
        }
        if (!tabs.some(t => t.label && t.label.toLowerCase().includes('ledger'))) {
          const insertIdx = tabs.findIndex(t => t.label && t.label.toLowerCase().includes('wallet point')) + 1;
          tabs.splice(insertIdx > 0 ? insertIdx : 1, 0, { _id: 'tab_wallet_ledger', label: 'Wallet Ledger' });
        }
        setTopTabsData(tabs);
        if (tabs.length > 0) setActiveTabId(tabs[0]._id || tabs[0].id);
      });

    // Fetch Sidebar Menus
    fetch(`${API_URL}/api/sidebar-menus`)
      .then(res => res.json())
      .then(data => {
        let menus = Array.isArray(data) ? data.filter(m => {
          if (!m.label) return true;
          const l = m.label.toLowerCase();
          return !l.includes('wallet') && !l.includes('ledger') && !l.includes('report');
        }) : [];

        // Ensure Quick Links is present in the sidebar
        const hasQuick = menus.some(m => {
          if (!m.label) return false;
          const matched = getDynamicMenuForSidebarItem(m);
          if (matched) return false;
          const l = m.label.toLowerCase();
          const u = (m.url || '').toLowerCase();
          return l.includes('quick') || l === 'view links' || u === '/quick-links' || u === '/view-links';
        });

        if (!hasQuick) {
          const panIdx = menus.findIndex(m => m.label && m.label.toLowerCase().includes('pan'));
          const quickMenuItem = { _id: 'menu_quick_links', label: 'QUICK LINKS', url: '/quick-links', isActive: false };
          if (panIdx >= 0) {
            menus.splice(panIdx + 1, 0, quickMenuItem);
          } else {
            menus.push(quickMenuItem);
          }
        }

        // Ensure all 10 dynamic link menus are present (without duplicating)
        DYNAMIC_LINK_MENUS.forEach(dyn => {
          const exists = menus.some(m => {
            const matched = getDynamicMenuForSidebarItem(m);
            return matched && matched.key === dyn.key;
          });
          if (!exists) {
            menus.push({
              _id: `dyn_menu_${dyn.key}`,
              label: dyn.label,
              url: dyn.route,
              isActive: false
            });
          }
        });

        // Deduplicate any menus that match the same dynamic menu or quick links
        const seenKeys = new Set();
        const dedupedMenus = [];
        menus.forEach(m => {
          const matchedDyn = getDynamicMenuForSidebarItem(m);
          if (matchedDyn) {
            if (!seenKeys.has(matchedDyn.key)) {
              seenKeys.add(matchedDyn.key);
              dedupedMenus.push({
                ...m,
                label: (m.label && m.label.trim()) ? m.label.trim() : matchedDyn.label,
                url: matchedDyn.route,
                isActive: m.isActive !== undefined ? Boolean(m.isActive) : true
              });
            }
          } else {
            const l = (m.label || '').toLowerCase();
            const u = (m.url || '').toLowerCase();
            const isQuickItem = l.includes('quick') || l === 'view links' || u === '/quick-links' || u === '/view-links';
            if (isQuickItem) {
              if (!seenKeys.has('quickLinks')) {
                seenKeys.add('quickLinks');
                dedupedMenus.push({
                  ...m,
                  label: (m.label && m.label.trim()) ? m.label.trim() : 'QUICK LINKS',
                  url: '/quick-links'
                });
              }
            } else {
              dedupedMenus.push(m);
            }
          }
        });

        setSidebarMenuData(dedupedMenus);
        const activeItem = dedupedMenus.find(m => m.isActive) || dedupedMenus[0];
        if (activeItem) {
          setActiveMenuId(activeItem._id || activeItem.id);
        }
      });

    // Fetch Banners
    fetch(`${API_URL}/api/banners`)
      .then(res => res.json())
      .then(data => {
        setBannersData(data);
        if (data.length > 0) setActiveBannerId(data[0]._id || data[0].id);
      });



    // Setup an interval to periodically fetch wallet balance
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      const fetchWalletBalance = () => {
        fetch(`${API_URL}/api/users/${currentUser}`)
          .then(res => res.json())
          .then(data => {
            if (data.walletBalance !== undefined) {
              setWalletBalance(data.walletBalance);
            }

          })
          .catch(err => console.error(err));
      };

      fetchWalletBalance(); // Initial fetch
      const interval = setInterval(fetchWalletBalance, 5000); // Poll every 5 seconds
      return () => clearInterval(interval);
    }
  }, []);

  return (
    <div className={`dashboard-container-new theme-${theme}`}>
      {/* Ambient Glowing Orbs */}
      <div className="ambient-orb orb-1"></div>
      <div className="ambient-orb orb-2"></div>
      <div className="ambient-orb orb-3"></div>

      {/* Top Header Bar */}
      <div className="dash-top-title">
        <div className="header-left-group" style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <button
            className="mobile-hamburger-btn"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle Mobile Navigation"
          >
            {isMobileMenuOpen ? '✕' : '☰'}
          </button>
          <div className="header-brand-logo" onClick={() => { setIsMobileMenuOpen(false); navigate('/dashboard'); }} style={{ cursor: 'pointer' }}>
            <div className="header-logo-badge-round">
              <img src={logoImg} alt="MB MITRA" className="header-logo-img" onError={(e) => e.target.style.display = 'none'} />
            </div>
            <span className="brand-gold-text">MITRA</span>
          </div>
        </div>

        <div className="title-marquee-wrapper">
          <div className="title-marquee-text">
            {marqueeText || 'WELCOME TO MB MITRA'}
          </div>
        </div>

        <div className="header-right-controls">
          <NotificationBell dark={theme === 'dark'} />
          <div
            className="top-wallet-box"
            onClick={() => { setWalletTab('directPayment'); navigate('/wallet'); }}
            title="Click to view My Wallet & Load Wallet Requisition"
          >
            <span className="wallet-icon">💼</span>
            <span className="wallet-label-text">Wallet Balance:</span>
            <span className="wallet-amount-text">
              {showBalance ? `₹ ${parseFloat(walletBalance).toFixed(2)}` : '₹ •••••'}
            </span>
          </div>

          <button
            className="top-profile-btn"
            onClick={() => setShowProfileMenu(!showProfileMenu)}
          >
            <span className="profile-avatar-icon">👤</span>
            <span>{localStorage.getItem('currentUser') || 'My Profile'}</span>
            <span className="dropdown-caret">▼</span>
          </button>

          {showProfileMenu && (
            <div className="profile-dropdown-card">
              <div className="dropdown-user-info">
                <div className="user-info-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span className="user-info-label">Wallet Balance</span>
                  <span
                    style={{ cursor: 'pointer', fontSize: '15px' }}
                    onClick={toggleShowBalance}
                    title={showBalance ? "Hide Balance" : "Show Balance"}
                  >
                    {showBalance ? '🔒' : '👁️'}
                  </span>
                </div>
                <div className="user-info-amount">
                  {showBalance ? `₹ ${parseFloat(walletBalance).toFixed(2)}` : '₹ •••••'}
                </div>
              </div>
              <div className="dropdown-divider"></div>
              <button
                className="dropdown-action-item"
                onClick={() => { setWalletTab('directPayment'); setShowProfileMenu(false); navigate('/wallet'); }}
              >
                💼 Load Wallet / Request
              </button>
              <button
                className="dropdown-action-item"
                onClick={() => { setShowProfileMenu(false); navigate('/ledger'); }}
              >
                📒 Ledger
              </button>
              <div className="dropdown-divider"></div>
              <div className="dropdown-theme-section">
                <div style={{ padding: '4px 20px', fontSize: '11px', fontWeight: 800, color: theme === 'light' ? '#ea580c' : '#fb923c', letterSpacing: '0.5px' }}>THEME OPTIONS</div>
                <div className="theme-options-row">
                  <button
                    type="button"
                    className={`theme-option-btn ${theme === 'light' ? 'active' : ''}`}
                    onClick={() => { setTheme('light'); localStorage.setItem('appTheme', 'light'); }}
                  >
                    ☀️ White
                  </button>
                  <button
                    type="button"
                    className={`theme-option-btn ${theme === 'dark' ? 'active' : ''}`}
                    onClick={() => { setTheme('dark'); localStorage.setItem('appTheme', 'dark'); }}
                  >
                    🌙 Black
                  </button>
                </div>
              </div>
              <div className="dropdown-divider"></div>
              <button
                className="dropdown-action-item logout-btn"
                onClick={() => { localStorage.removeItem('currentUser'); navigate('/'); }}
              >
                🚪 Logout
              </button>
            </div>
          )}
        </div>
      </div>

      {/* My Wallet Modal Overlay */}
      {!isWalletRoute && (
        <WalletModal
          isOpen={showWallet}
          onClose={() => { setShowWallet(false); navigate('/dashboard'); }}
          currentUser={localStorage.getItem('currentUser')}
          initialTab={walletTab}
          walletBalance={walletBalance}
          onBalanceUpdate={(newBal) => setWalletBalance(newBal)}
          theme={theme}
        />
      )}

      {/* Main Layout */}
      <div className="dash-main-new">
        {/* Mobile Backdrop Overlay */}
        {isMobileMenuOpen && (
          <div
            className="sidebar-mobile-backdrop"
            onClick={() => setIsMobileMenuOpen(false)}
          />
        )}

        {/* Left Glass Sidebar */}
        <div className={`sidebar-new ${isMobileMenuOpen ? 'mobile-open' : ''}`}>
          {/* Top Subtle Amber Wave Curve */}
          <svg className="sidebar-wave-overlay" viewBox="0 0 240 160" preserveAspectRatio="none">
            <defs>
              <linearGradient id="amberWaveGrad" x1="0%" y1="100%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#ea580c" stopOpacity="0.9" />
                <stop offset="50%" stopColor="#c2410c" stopOpacity="0.7" />
                <stop offset="100%" stopColor="#7c2d12" stopOpacity="0.2" />
              </linearGradient>
            </defs>
            <path
              d="M -10,120 C 50,90 100,50 140,30 C 180,10 210,5 250,-5"
              fill="none"
              stroke="url(#amberWaveGrad)"
              strokeWidth="3.5"
              strokeLinecap="round"
            />
          </svg>

          <div className="sidebar-brand-section">
            <div className="sidebar-logo-wrapper">
              <div className="logo-glowing-ring"></div>
              <img src={logoImg} alt="MB MITRA" className="sidebar-logo-img" onError={(e) => e.target.style.display = 'none'} />
            </div>
            <span className="sidebar-brand-title">MB MITRA</span>
          </div>

          <div className="sidebar-divider-title">
            <span>— • SERVICES • —</span>
          </div>

          <div className="sidebar-menu-new">
            {sidebarMenuData.filter((menu) => {
              const matchedDyn = getDynamicMenuForSidebarItem(menu) || findDynamicMenu(menu.url || menu.label);
              if (matchedDyn) {
                return Boolean(menu.isActive);
              }
              return true;
            }).map((menu) => {
              const menuId = menu._id || menu.id;
              const isPan = menu.label && menu.label.toLowerCase().includes('pan');
              const isDash = menu.label && menu.label.toLowerCase().includes('dash');
              const matchedDyn = getDynamicMenuForSidebarItem(menu) || findDynamicMenu(menu.url || menu.label);
              const isQuick = !matchedDyn && (
                menu.url === '/quick-links' ||
                menu.url === '/view-links' ||
                (menu.label && (menu.label.toLowerCase().includes('quick') || menu.label.toLowerCase() === 'view links'))
              );
              const isDynSelected = matchedDyn && activeDynLinkMenu && matchedDyn.key === activeDynLinkMenu.key;
              const isSelected = isDynSelected ? true : (isPan ? isPanCardRoute : (isQuick ? isQuickLinksRoute : (isDash ? !isStandaloneRoute : activeMenuId === menuId)));

              return (
                <div
                  key={menuId}
                  className={`menu-item-new ${isSelected ? 'active' : ''} ${!menu.label ? 'empty' : ''}`}
                  onClick={() => {
                    setActiveMenuId(menuId);
                    setIsMobileMenuOpen(false);
                    if (matchedDyn) {
                      navigate(matchedDyn.route);
                    } else if (isPan) {
                      navigate('/pancard');
                    } else if (isQuick) {
                      navigate('/quick-links');
                    } else if (menu.url && menu.url.trim() !== '') {
                      const targetUrl = menu.url.trim();
                      if (targetUrl.startsWith('http://') || targetUrl.startsWith('https://')) {
                        window.open(targetUrl, '_blank');
                      } else {
                        navigate(targetUrl);
                      }
                    } else if (isDash) {
                      navigate('/dashboard');
                    } else if (menu.label && (menu.label.toLowerCase().includes('report') || menu.label.toLowerCase().includes('ledger'))) {
                      navigate('/ledger');
                    } else if (menu.label && menu.label.toLowerCase().includes('wallet')) {
                      navigate('/wallet');
                    }
                  }}
                >
                  {getMenuIcon(menu.label, menu.url)}
                  <span className="menu-label-text">{menu.label}</span>
                  <span className="active-chevron">›</span>
                </div>
              );
            })}
          </div>

          {/* Bottom Subtle Amber Wave Stroke Lines */}
          <svg className="sidebar-bottom-wave-overlay" viewBox="0 0 240 160" preserveAspectRatio="none">
            <defs>
              <linearGradient id="amberBottomWaveGrad" x1="0%" y1="100%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#ea580c" stopOpacity="0.9" />
                <stop offset="50%" stopColor="#c2410c" stopOpacity="0.7" />
                <stop offset="100%" stopColor="#7c2d12" stopOpacity="0.2" />
              </linearGradient>
            </defs>
            <path
              d="M 10,160 C 70,135 140,125 245,60"
              fill="none"
              stroke="url(#amberBottomWaveGrad)"
              strokeWidth="3"
              strokeLinecap="round"
            />
            <path
              d="M 50,160 C 100,145 150,135 245,90"
              fill="none"
              stroke="url(#amberBottomWaveGrad)"
              strokeWidth="2"
              opacity="0.6"
              strokeLinecap="round"
            />
          </svg>
        </div>

        {/* Main Content Area */}
        <div className="content-area-new">

          {/* Top Header Tabs */}
          {topTabsData.length > 0 && (
            <div className="top-tabs-new">
              {topTabsData.map((tab) => {
                const tabId = tab._id || tab.id;
                const label = (tab.label || '').toLowerCase();
                const isSelected = 
                  (isWalletRoute && label.includes('wallet')) ||
                  (isLedgerRoute && label.includes('ledger')) ||
                  (!isStandaloneRoute && activeTabId === tabId);

                return (
                  <button
                    key={tabId}
                    className={`tab-btn-new ${isSelected ? 'active' : ''}`}
                    onClick={() => {
                      setActiveTabId(tabId);
                      if (label.includes('ledger') || label.includes('report')) {
                        navigate('/ledger');
                      } else if (label.includes('wallet')) {
                        navigate('/wallet');
                      } else {
                        navigate('/dashboard');
                        if (tab.url) window.open(tab.url, '_blank');
                      }
                    }}
                    style={{ cursor: 'pointer' }}
                  >
                    {getTabIcon(tab.label)}
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>
          )}

          {/* Action Cards Marquee Showcase (Only show on Dashboard, hide on Ledger & Wallet routes) */}
          {!isStandaloneRoute && (
            <div className="action-cards-container">
              <div className="action-cards-wrapper">
                <div className="action-cards-track-scroll">
                  {[...actionCardsData, ...actionCardsData].map((card, index) => {
                    const cardId = card._id || card.id;
                    const isSelected = activeCardId === cardId;
                    return (
                      <div key={(cardId || 'card') + '-' + index} className="action-card-new">
                        <div
                          className={`action-card-inner ${isSelected ? 'active' : ''}`}
                          style={{ cursor: 'pointer' }}
                          onClick={() => {
                            setActiveCardId(cardId);
                            if (card.url) window.open(card.url, '_blank');
                          }}
                        >
                          <img
                            src={card.img}
                            alt={card.title || 'Service'}
                            className="card-img"
                            onError={(e) => { e.target.style.display = 'none'; e.target.nextSibling.style.display = 'flex'; }}
                          />

                          {card.isAeps ? (
                            <div className="card-fallback aeps-fallback" style={{ display: 'none' }}>
                              <div className="aeps-e">e</div>
                              <div className="aeps-text">A <span>P S</span></div>
                            </div>
                          ) : (
                            <div className="card-fallback" style={{ display: 'none' }}>{card.icon || '💳'}</div>
                          )}

                          <div className="card-hover-overlay">
                            <span className="card-open-btn">Open Service →</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* Main Content Display: Ledger View, Wallet View, or Banner Showcase */}
          {isLedgerRoute ? (
            <LedgerView currentUser={localStorage.getItem('currentUser')} walletBalance={walletBalance} />
          ) : isWalletRoute ? (
            <WalletModal
              isOpen={true}
              inlineMode={true}
              onClose={() => navigate('/dashboard')}
              currentUser={localStorage.getItem('currentUser')}
              initialTab={walletTab}
              walletBalance={walletBalance}
              onBalanceUpdate={(newBal) => setWalletBalance(newBal)}
              theme={theme}
            />
          ) : isPanCardRoute ? (
            <PanCardView
              currentUser={localStorage.getItem('currentUser')}
              walletBalance={walletBalance}
              onClose={() => navigate('/dashboard')}
              theme={theme}
            />
          ) : isQuickLinksRoute ? (() => {
            const quickItem = (sidebarMenuData || []).find(m => {
              const d = getDynamicMenuForSidebarItem(m);
              if (d) return false;
              const l = (m.label || '').toLowerCase();
              const u = (m.url || '').toLowerCase();
              return l.includes('quick') || l === 'view links' || u === '/quick-links' || u === '/view-links';
            });
            const quickTitle = (quickItem && quickItem.label && quickItem.label.trim()) || 'Available links';
            return (
              <QuickLinksView 
                menuKey="quickLinks"
                pageTitle={quickTitle}
                pageSubtitle="Access important form links, video guides and portals instantly"
                theme={theme} 
                currentUser={localStorage.getItem('currentUser')}
                walletBalance={walletBalance}
                onBalanceUpdate={(newBal) => setWalletBalance(newBal)}
              />
            );
          })() : isDynLinkMenuRoute ? (() => {
            const currentDynItem = (sidebarMenuData || []).find(m => {
              const d = getDynamicMenuForSidebarItem(m);
              return d && d.key === activeDynLinkMenu.key;
            });
            const isMenuOff = currentDynItem && currentDynItem.isActive === false;
            const dynTitle = (currentDynItem && currentDynItem.label && currentDynItem.label.trim()) || activeDynLinkMenu.label;

            if (isMenuOff) {
              return (
                <div style={{ padding: '60px 20px', textAlign: 'center', background: '#ffffff', borderRadius: '16px', margin: '20px', boxShadow: '0 4px 16px rgba(0,0,0,0.06)' }}>
                  <div style={{ fontSize: '48px', marginBottom: '14px' }}>🔒</div>
                  <h2 style={{ fontSize: '20px', fontWeight: 800, color: '#1e293b', marginBottom: '8px' }}>
                    {dynTitle} is Currently Inactive
                  </h2>
                  <p style={{ color: '#64748b', fontSize: '14px', maxWidth: '420px', margin: '0 auto 20px' }}>
                    This menu section has been turned OFF by the administrator.
                  </p>
                  <button 
                    onClick={() => navigate('/dashboard')}
                    style={{ padding: '10px 24px', borderRadius: '8px', background: '#3b82f6', color: '#fff', border: 'none', fontWeight: 700, cursor: 'pointer' }}
                  >
                    Go to Dashboard
                  </button>
                </div>
              );
            }

            return (
              <QuickLinksView 
                menuKey={activeDynLinkMenu.key}
                pageTitle={dynTitle}
                pageSubtitle={`Available dynamic links and portals for ${dynTitle}`}
                theme={theme} 
                currentUser={localStorage.getItem('currentUser')}
                walletBalance={walletBalance}
                onBalanceUpdate={(newBal) => setWalletBalance(newBal)}
              />
            );
          })() : (
            bannersData.length > 0 && (
              <div className={`banner-area-new ${activeBannerId ? 'active' : ''}`}>
                {bannersData.map((banner) => {
                  const bannerId = banner._id || banner.id;
                  const isSelected = activeBannerId === bannerId;
                  return (
                    <div
                      key={bannerId}
                      className={`banner-item-wrapper ${isSelected ? 'active' : ''}`}
                      onClick={() => setActiveBannerId(bannerId)}
                      style={{ cursor: 'pointer' }}
                    >
                      <img
                        src={banner.img}
                        alt={banner.alt || 'Banner'}
                        className="banner-img"
                        onError={(e) => { e.target.style.display = 'none'; e.target.nextSibling.style.display = 'flex'; }}
                      />
                      <div className="banner-fallback" style={{ display: 'none' }}>
                        <div className="sun-new"></div>
                        <div className="plane-shadow">{banner.fallbackIcon}</div>
                        <div className="person-shadow">{banner.fallbackPerson}</div>
                      </div>
                      <div className="banner-shine-overlay"></div>
                    </div>
                  );
                })}
              </div>
            )
          )}

        </div>
      </div>

    </div>
  );
};

export default Dashboard;
